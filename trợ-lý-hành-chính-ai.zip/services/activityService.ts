
import { UserActivity, DocVersion, ChatSession, KnowledgeDocument, Message } from '../types';

const STORAGE_KEYS = {
  ACTIVITIES: 'gov_ai_activities_',
  VERSIONS: 'gov_ai_versions_',
  SESSIONS: 'gov_ai_sessions_',
  KNOWLEDGE: 'gov_ai_knowledge_index_',
};

// --- HỆ THỐNG NHẬT KÝ (AUDIT LOGS) ---
export const logActivity = (userEmail: string, type: UserActivity['type'], description: string, metadata?: any) => {
  const key = STORAGE_KEYS.ACTIVITIES + userEmail;
  const activities: UserActivity[] = JSON.parse(localStorage.getItem(key) || '[]');
  const newActivity: UserActivity = {
    id: `act_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    type,
    description,
    timestamp: new Date().toISOString(),
    metadata
  };
  localStorage.setItem(key, JSON.stringify([newActivity, ...activities].slice(0, 100)));
};

export const getActivities = (userEmail: string): UserActivity[] => {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.ACTIVITIES + userEmail) || '[]');
};

// --- QUẢN LÝ PHIÊN CHAT (SESSIONS) ---
export const saveChatSession = (userEmail: string, session: ChatSession) => {
  const key = STORAGE_KEYS.SESSIONS + userEmail;
  const sessions: ChatSession[] = JSON.parse(localStorage.getItem(key) || '[]');
  const index = sessions.findIndex(s => s.id === session.id);
  
  if (index >= 0) {
    sessions[index] = { ...session, lastUpdate: new Date().toISOString() };
  } else {
    sessions.unshift({ ...session, lastUpdate: new Date().toISOString() });
  }
  
  localStorage.setItem(key, JSON.stringify(sessions.slice(0, 20))); // Giữ 20 session gần nhất
};

export const getChatSessions = (userEmail: string, type?: 'LEGAL' | 'DOC_CONTEXT'): ChatSession[] => {
  const all: ChatSession[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.SESSIONS + userEmail) || '[]');
  return type ? all.filter(s => s.type === type) : all;
};

// --- QUẢN LÝ KHO TRI THỨC (KNOWLEDGE INDEX) ---
export const updateKnowledgeIndex = (userEmail: string, docs: KnowledgeDocument[]) => {
  localStorage.setItem(STORAGE_KEYS.KNOWLEDGE + userEmail, JSON.stringify(docs));
};

export const getKnowledgeIndex = (userEmail: string): KnowledgeDocument[] => {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.KNOWLEDGE + userEmail) || '[]');
};

// --- QUẢN LÝ DỰ THẢO (DRAFT VERSIONS) ---
export const saveDocVersion = (userEmail: string, name: string, content: string, type: string) => {
  const key = STORAGE_KEYS.VERSIONS + userEmail;
  const versions: DocVersion[] = JSON.parse(localStorage.getItem(key) || '[]');
  const newVersion: DocVersion = {
    id: `ver_${Date.now()}`,
    name,
    content,
    type,
    timestamp: new Date().toISOString()
  };
  localStorage.setItem(key, JSON.stringify([newVersion, ...versions]));
  logActivity(userEmail, 'DOC_SAVE', `Đã lưu phiên bản dự thảo: ${name}`);
  return newVersion;
};

export const getDocVersions = (userEmail: string): DocVersion[] => {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.VERSIONS + userEmail) || '[]');
};

export const deleteDocVersion = (userEmail: string, versionId: string) => {
  const key = STORAGE_KEYS.VERSIONS + userEmail;
  const versions: DocVersion[] = JSON.parse(localStorage.getItem(key) || '[]');
  localStorage.setItem(key, JSON.stringify(versions.filter(v => v.id !== versionId)));
};
