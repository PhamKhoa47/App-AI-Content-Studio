
import { GoogleGenAI, Type, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const cleanMarkdown = (text: string) => {
  return text
    .replace(/```[a-z]*\n?|```/g, '') 
    .replace(/^\s*#+\s+/gm, '')      
    .replace(/\*\*/g, '')            
    .replace(/\*/g, '')              
    .replace(/__/g, '')              
    .replace(/\`([^\`]+)\`/g, '$1')     
    .trim();
};

export const SYSTEM_PROMPTS = {
  legal_assistant: `Bạn là Trợ lý Pháp lý ảo cấp cao của Chính phủ Việt Nam. 
    Nhiệm vụ: 
    - Giải đáp chính xác, khách quan các quy định pháp luật.
    - LUÔN LUÔN trích dẫn rõ căn cứ: "Căn cứ theo Điều..., Khoản..., Luật/Nghị định số...".
    - Sử dụng ngôn ngữ hành chính chuẩn mực: "Kính thưa đồng chí", "Theo quy định hiện hành", "Trân trọng".`,
  
  drafting_assistant: `Bạn là chuyên gia soạn thảo văn bản hành chính theo Nghị định 30/2020/NĐ-CP.
    QUY TẮC CỨNG:
    1. CHỈ TRẢ VỀ NỘI DUNG CHÍNH (Từ phần Căn cứ đến hết nội dung văn bản).
    2. KHÔNG có Quốc hiệu, Tiêu ngữ, Tên cơ quan, Trích yếu, Chữ ký.
    3. PHẦN NƠI NHẬN: Cuối văn bản, hãy liệt kê danh sách nơi nhận (mỗi dòng một gạch đầu dòng), nhưng TUYỆT ĐỐI KHÔNG ghi chữ "NƠI NHẬN:" hoặc bất kỳ tiêu đề nào tương tự ở phía trước.
    4. KHÔNG sử dụng ký hiệu Markdown như #, **, *. 
    5. Văn phong: Trang trọng, chính xác, không thừa từ.`,

  suggest_phrasing: `Bạn là chuyên gia ngôn ngữ hành chính. Đưa ra 3 phương án gợi ý chuẩn công vụ, súc tích cho đoạn văn bản được yêu cầu.`,

  standardize_style: (currentDraft: string) => `Hãy rà soát và chỉnh sửa văn bản sau theo Nghị định 30/2020/NĐ-CP: 
    - Viết hoa đúng quy định (VD: Chính phủ, UBND, Nhà nước).
    - Câu từ gãy gọn.
    - Không kèm lời dẫn.
    Văn bản: ${currentDraft}`,

  refine_draft: (currentDraft: string) => `Hãy hiệu chỉnh bản dự thảo sau theo yêu cầu của người dùng: ${currentDraft}`,

  knowledge_preview: `Tóm tắt nội dung chính của văn bản pháp luật sau một cách khoa học, ngắn gọn.`,

  document_chat: (docTitle: string, docSummary: string) => `Trả lời câu hỏi về văn bản "${docTitle}" dựa trên tóm tắt: ${docSummary}`
};

export const chatWithLegalAIStream = async (message: string) => {
  return await ai.models.generateContentStream({
    model: 'gemini-3-flash-preview',
    contents: message,
    config: {
      systemInstruction: SYSTEM_PROMPTS.legal_assistant,
      temperature: 0.1,
      tools: [{ googleSearch: {} }],
    },
  });
};

export const generateDraft = async (type: string, data: any) => {
  const prompt = `Soạn thảo ${type}. Trích yếu: ${data.subject}. Căn cứ: ${data.reason}. Nội dung: ${data.content}.`;
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_PROMPTS.drafting_assistant,
      temperature: 0.1,
    },
  });
  return cleanMarkdown(response.text || '');
};

export const suggestPhrasing = async (text: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Gợi ý câu chữ: "${text}"`,
    config: {
      systemInstruction: SYSTEM_PROMPTS.suggest_phrasing,
      temperature: 0.7,
    },
  });
  return cleanMarkdown(response.text || '');
};

export const standardizeStyle = async (currentDraft: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: "Chuẩn hóa văn phong.",
    config: {
      systemInstruction: SYSTEM_PROMPTS.standardize_style(currentDraft),
      temperature: 0.1,
    },
  });
  return cleanMarkdown(response.text || '');
};

export const refineDraftContent = async (currentDraft: string, instructions: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: instructions,
    config: {
      systemInstruction: SYSTEM_PROMPTS.refine_draft(currentDraft),
      temperature: 0.2,
    },
  });
  return cleanMarkdown(response.text || '');
};

export const getDocPreview = async (docTitle: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Tóm tắt văn bản: ${docTitle}`,
    config: {
      systemInstruction: SYSTEM_PROMPTS.knowledge_preview,
    },
  });
  return response.text;
};

export const chatWithDoc = async (docTitle: string, docSummary: string, userMessage: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: userMessage,
    config: {
      systemInstruction: SYSTEM_PROMPTS.document_chat(docTitle, docSummary),
    },
  });
  return response.text;
};
