
import React, { useState, useEffect, useMemo } from 'react';
import { ViewMode, User } from './types';
import Layout from './components/Layout';
import LegalAssistant from './components/LegalAssistant';
import DocumentDrafting from './components/DocumentDrafting';
import KnowledgeBase from './components/KnowledgeBase';
import LicenseManagement from './components/LicenseManagement';
import Profile from './components/Profile';
import Login from './components/Login';
import TrialExpired from './components/TrialExpired';
import Dashboard from './components/Dashboard';
import DesktopBuild from './components/DesktopBuild';
import { logActivity } from './services/activityService';
import { SYSTEM_MESSAGES, AUTHOR_INFO } from './constants';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewMode>(ViewMode.DASHBOARD);
  const [user, setUser] = useState<User | null>(null);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('ai_assistant_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('ai_assistant_user', JSON.stringify(userData));
    localStorage.setItem(`reg_date_${userData.email}`, userData.registrationDate);
    logActivity(userData.email, 'LOGIN', 'Truy cập hệ thống thành công');
    setShowWelcomeModal(true); // Hiển thị thông báo AI khi đăng nhập
  };

  const handleLogout = () => {
    if (user) {
      logActivity(user.email, 'LOGIN', 'Đã đăng xuất');
    }
    setUser(null);
    localStorage.removeItem('ai_assistant_user');
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUser(updatedUser);
    localStorage.setItem('ai_assistant_user', JSON.stringify(updatedUser));
    const registeredUsers = JSON.parse(localStorage.getItem('registered_users') || '{}');
    if (registeredUsers[updatedUser.email]) {
      registeredUsers[updatedUser.email] = { ...registeredUsers[updatedUser.email], ...updatedUser };
      localStorage.setItem('registered_users', JSON.stringify(registeredUsers));
    }
  };

  const trialStatus = useMemo(() => {
    if (!user) return { expired: false, daysLeft: 7 };
    
    const regDate = new Date(user.registrationDate).getTime();
    const now = new Date().getTime();
    const diffTime = now - regDate;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    return {
      expired: diffDays >= 7,
      daysLeft: Math.max(0, 7 - diffDays)
    };
  }, [user]);

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  if (trialStatus.expired) {
    return <TrialExpired user={user} onLogout={handleLogout} />;
  }

  const renderContent = () => {
    switch (currentView) {
      case ViewMode.LEGAL_ASSISTANT:
        return <LegalAssistant user={user} />;
      case ViewMode.DRAFTING:
        return <DocumentDrafting user={user} />;
      case ViewMode.KNOWLEDGE_BASE:
        return <KnowledgeBase user={user} />;
      case ViewMode.LICENSE_MANAGEMENT:
        return <LicenseManagement user={user} daysLeft={trialStatus.daysLeft} />;
      case ViewMode.PROFILE:
        return <Profile user={user} daysLeft={trialStatus.daysLeft} onUpdate={handleUpdateUser} />;
      case ViewMode.DESKTOP_BUILD:
        return <DesktopBuild user={user} />;
      default:
        return <Dashboard user={user} />;
    }
  };

  return (
    <>
      <Layout 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        user={user} 
        onLogout={handleLogout}
        daysLeft={trialStatus.daysLeft}
      >
        {renderContent()}
      </Layout>

      {/* Welcome & AI Disclaimer Modal */}
      {showWelcomeModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-fadeIn">
           <div className="max-w-2xl w-full bg-white rounded-[3rem] shadow-[0_0_80px_rgba(0,0,0,0.5)] overflow-hidden animate-slideUp border border-white/20">
              <div className="official-gradient p-10 text-center relative overflow-hidden">
                 <div className="absolute inset-0 trong-dong-pattern opacity-10 pointer-events-none"></div>
                 <div className="w-20 h-20 bg-white/20 rounded-3xl mx-auto flex items-center justify-center mb-6 border border-white/20 shadow-2xl backdrop-blur-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                 </div>
                 <h2 className="text-xl font-black text-white uppercase tracking-widest">{SYSTEM_MESSAGES.welcome_title}</h2>
                 <p className="text-blue-200 text-[10px] font-bold mt-2 uppercase tracking-[0.3em] opacity-80">Kiến trúc bởi chuyên gia {AUTHOR_INFO.name}</p>
              </div>

              <div className="p-10 space-y-8 bg-white">
                 <div className="space-y-4">
                    <h3 className="text-xs font-black text-red-600 uppercase tracking-widest flex items-center">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                       {SYSTEM_MESSAGES.disclaimer_header}
                    </h3>
                    <div className="space-y-3 bg-slate-50 p-6 rounded-3xl border border-slate-100 shadow-inner">
                       {SYSTEM_MESSAGES.disclaimer_content.map((item, idx) => (
                         <p key={idx} className="text-[12px] text-slate-700 leading-relaxed font-semibold">
                           {item}
                         </p>
                       ))}
                    </div>
                 </div>

                 <div className="p-5 bg-blue-50 border border-blue-100 rounded-3xl">
                    <p className="text-sm text-blue-900 leading-relaxed font-bold text-center">
                       {SYSTEM_MESSAGES.welcome_note}
                    </p>
                 </div>

                 <div className="flex flex-col space-y-3 pt-2">
                    <button 
                       onClick={() => setShowWelcomeModal(false)}
                       className="w-full py-5 official-gradient text-white rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-2xl hover:brightness-110 active:scale-[0.98] transition-all"
                    >
                       Tôi đã đọc, hiểu và đồng ý truy cập
                    </button>
                    <div className="flex justify-between items-center text-[8px] text-slate-400 font-black uppercase tracking-widest px-1">
                       <span>© 2025 Phạm Văn Khoa</span>
                       <span>khoa47ai@gmail.com</span>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}
    </>
  );
};

export default App;
