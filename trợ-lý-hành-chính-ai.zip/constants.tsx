
import React from 'react';

export const AUTHOR_INFO = {
  name: "Phạm Văn Khoa",
  role: "Kiến trúc sư Hệ thống AI",
  phone: "0989.113.602",
  email: "khoa47ai@gmail.com",
  website: "khoapv.gov.vn",
  id: "PVK-2025-AI-GOV",
  signature: "Phê duyệt bởi Phạm Văn Khoa"
};

export const SYSTEM_MESSAGES = {
  welcome_title: "HỆ THỐNG TRỢ LÝ ẢO HÀNH CHÍNH QUỐC GIA",
  welcome_note: "Chào mừng đồng chí đã truy cập hệ thống Quản trị Thông minh. Hãy sử dụng trí tuệ nhân tạo để tối ưu hóa hiệu suất công vụ một cách có trách nhiệm.",
  disclaimer_header: "THÔNG BÁO QUAN TRỌNG VỀ TRÍ TUỆ NHÂN TẠO & MIỄN TRỪ TRÁCH NHIỆM",
  disclaimer_content: [
    "1. Các kết quả tra cứu, tóm tắt và dự thảo văn bản được tạo ra hoàn toàn bằng Trí tuệ nhân tạo (AI) và chỉ mang tính chất THAM KHẢO.",
    "2. Hệ thống KHÔNG thay thế cho các văn bản quy phạm pháp luật gốc, các quy trình nghiệp vụ và thẩm định chính thức theo quy định.",
    "3. Cán bộ sử dụng có trách nhiệm TUYỆT ĐỐI trong việc đối chiếu, rà soát và hiệu đính nội dung do AI cung cấp trước khi chính thức ban hành hoặc thực hiện.",
    "4. Tác giả Phạm Văn Khoa (khoa47ai@gmail.com) và đơn vị vận hành không chịu bất kỳ trách nhiệm pháp lý nào đối với sai sót hoặc hậu quả phát sinh từ việc sử dụng thông tin của AI mà không qua kiểm chứng chuyên môn."
  ],
  footer_note: "Xác thực bởi Hệ thống Quản trị AI Phạm Khoa - 2025"
};

export const COLORS = {
  primary: '#003366', // Navy Blue - Uy quyền
  secondary: '#C5A059', // Muted Gold - Trang trọng
  accent: '#1D4ED8', // Blue 700
  background: '#F8FAFC',
  text: '#1E293B',
};

export const ICONS = {
  Dashboard: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 5a1 1 0 011-1h4a1 1 0 011 1v5a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v2a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zM14 12a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1v-7z" />
    </svg>
  ),
  Knowledge: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
    </svg>
  ),
  Assistant: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  ),
  Draft: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
    </svg>
  ),
  Security: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  ),
  Profile: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
};
