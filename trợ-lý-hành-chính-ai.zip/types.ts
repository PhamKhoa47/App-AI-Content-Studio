
export enum ViewMode {
  DASHBOARD = 'DASHBOARD',
  KNOWLEDGE_BASE = 'KNOWLEDGE_BASE',
  LEGAL_ASSISTANT = 'LEGAL_ASSISTANT',
  DRAFTING = 'DRAFTING',
  LICENSE_MANAGEMENT = 'LICENSE_MANAGEMENT',
  PROFILE = 'PROFILE',
  DESKTOP_BUILD = 'DESKTOP_BUILD'
}

export interface User {
  name: string;
  email: string;
  picture?: string;
  registrationDate: string; // ISO String
  unit?: string;       // Đơn vị (VD: UBND Tỉnh)
  department?: string; // Phòng ban (VD: Phòng Nội vụ)
  position?: string;   // Chức vụ (VD: Chánh văn phòng)
}

export interface UserActivity {
  id: string;
  type: 'LOGIN' | 'LEGAL_SEARCH' | 'DOC_DRAFT' | 'DOC_SAVE' | 'DOC_REFINE' | 'DOC_PRINT' | 'DOC_EXPORT' | 'KNOWLEDGE_UPLOAD';
  description: string;
  timestamp: string;
  metadata?: any;
}

export interface ChatSession {
  id: string;
  title: string;
  lastUpdate: string;
  messages: Message[];
  type: 'LEGAL' | 'DOC_CONTEXT';
  contextId?: string; // ID của document nếu là chat trong document
}

export interface DocVersion {
  id: string;
  name: string;
  content: string;
  timestamp: string;
  type: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: string; // ISO String để dễ lưu trữ
  sources?: { title?: string; uri?: string }[];
}

export interface KnowledgeDocument {
  id: string;
  title: string;
  type: string;
  category: string;
  source: string;
  date: string;
  size: string;
  status: string;
  department: string;
  summary?: string;
  chatHistory?: Message[];
}
