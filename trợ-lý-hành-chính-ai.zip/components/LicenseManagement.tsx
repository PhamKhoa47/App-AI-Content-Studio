
import React, { useState } from 'react';
import { User } from '../types';
import { AUTHOR_INFO } from '../constants';

interface LicenseManagementProps {
  user: User;
  daysLeft: number;
}

const LicenseManagement: React.FC<LicenseManagementProps> = ({ user, daysLeft }) => {
  const [licenseKey, setLicenseKey] = useState('');
  const [isActivating, setIsActivating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleActivate = () => {
    if (!licenseKey.trim()) return;
    setIsActivating(true);
    setError(null);
    
    setTimeout(() => {
      setIsActivating(false);
      setError(`Mã bản quyền không hợp lệ. Vui lòng liên hệ trực tiếp Quản trị viên ${AUTHOR_INFO.name} qua Hotline ${AUTHOR_INFO.phone} để nhận mã kích hoạt.`);
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fadeIn">
      {/* Header Info */}
      <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-40 w-40" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
        </div>
        
        <div className="flex items-center space-x-8 relative z-10">
          <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2rem] flex items-center justify-center text-white shadow-2xl shadow-blue-200 transform hover:rotate-6 transition-transform">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" /></svg>
          </div>
          <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tight">Cấp phép & Bản quyền</h2>
            <div className="flex items-center space-x-3 mt-2">
               <span className="px-4 py-1 bg-amber-100 text-amber-700 rounded-full text-[10px] font-black uppercase tracking-widest border border-amber-200">
                  Trial Mode
               </span>
               <span className="text-slate-400 text-xs font-bold">Kích hoạt: {new Date(user.registrationDate).toLocaleDateString('vi-VN')}</span>
            </div>
          </div>
        </div>

        <div className="text-center md:text-right relative z-10 bg-slate-50 px-8 py-6 rounded-3xl border border-slate-100 shadow-inner">
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Dùng thử còn lại</p>
           <p className="text-5xl font-black text-blue-600">{daysLeft} <span className="text-xl text-slate-300 uppercase">ngày</span></p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Activation Section */}
        <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-200 space-y-8 flex flex-col justify-between">
           <div>
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-[0.2em] flex items-center border-b pb-5 border-slate-100">
                 <div className="w-2 h-5 bg-blue-600 rounded-sm mr-4"></div>
                 Trung tâm kích hoạt
              </h3>
              <p className="text-xs text-slate-500 mt-6 leading-relaxed font-medium">
                 Vui lòng sử dụng mã bản quyền được cung cấp riêng cho đơn vị của đồng chí. Mã này sẽ mở khóa toàn bộ các tính năng AI nâng cao và xóa bỏ các giới hạn dùng thử.
              </p>
           </div>

           <div className="space-y-6">
              <div className="relative">
                <input 
                  type="text" 
                  value={licenseKey}
                  onChange={e => setLicenseKey(e.target.value)}
                  placeholder="MÃ BẢN QUYỀN (LICENSE KEY)"
                  className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-3xl font-mono text-sm focus:ring-4 focus:ring-blue-100 focus:border-blue-400 outline-none transition-all uppercase placeholder:text-slate-300 shadow-inner"
                />
              </div>
              {error && (
                <div className="p-5 bg-red-50 border border-red-100 rounded-2xl animate-shake">
                   <p className="text-[11px] text-red-600 font-bold leading-relaxed">{error}</p>
                </div>
              )}
              <button 
                onClick={handleActivate}
                disabled={isActivating || !licenseKey.trim()}
                className={`w-full py-5 rounded-3xl font-black text-white shadow-2xl transition-all flex items-center justify-center space-x-3 uppercase tracking-widest text-[10px] ${isActivating || !licenseKey.trim() ? 'bg-slate-200' : 'official-gradient hover:scale-[1.02] active:scale-[0.98] shadow-blue-900/20'}`}
              >
                {isActivating ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <span>Xác thực bản quyền</span>}
              </button>
           </div>
        </div>

        {/* Nâng cấp mạnh mẽ: Thẻ Chuyên gia Tác giả */}
        <div className="bg-[#001529] p-10 rounded-[2.5rem] text-white shadow-2xl flex flex-col justify-between relative overflow-hidden group">
           <div className="absolute inset-0 trong-dong-pattern opacity-10 pointer-events-none"></div>
           <div className="absolute top-0 right-0 p-10 opacity-20 group-hover:rotate-12 transition-transform duration-700">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-48 w-48" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={0.5} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-1.11-11.214a9.454 9.454 0 011.571-3.571m1.571 1.571a9.454 9.454 0 001.571-3.571m0 0a9.454 9.454 0 011.571 3.571m1.571-1.571a9.454 9.454 0 001.571 3.571M7.5 8c-1.505 0-2.75 1.245-2.75 2.75 0 1.505 1.245 2.75 2.75 2.75 1.505 0 2.75-1.245 2.75-2.75C10.25 9.245 9.005 8 7.5 8zm13.357 1.543l-.684-2.112-2.112-.684-2.112.684-.684 2.112.684 2.112 2.112.684 2.112-.684.684-2.112z" /></svg>
           </div>

           <div className="relative z-10">
              <div className="flex items-center space-x-5 mb-8 border-b border-white/10 pb-6">
                 <div className="w-16 h-16 bg-red-600 rounded-2xl flex flex-col items-center justify-center text-[10px] font-black shadow-2xl border-2 border-red-400 rotate-6 transform group-hover:rotate-0 transition-transform">
                    <span className="text-white">PHẠM</span>
                    <span className="text-yellow-400">KHOA</span>
                 </div>
                 <div>
                    <h3 className="text-xl font-black uppercase tracking-tight">{AUTHOR_INFO.name}</h3>
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em]">{AUTHOR_INFO.role}</p>
                 </div>
              </div>

              <div className="space-y-6">
                 <div className="bg-white/5 p-4 rounded-2xl border border-white/5 flex items-center space-x-4 hover:bg-white/10 transition-colors cursor-pointer">
                    <div className="w-10 h-10 bg-blue-600/20 text-blue-400 rounded-xl flex items-center justify-center">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                    </div>
                    <div>
                       <p className="text-[8px] font-black text-white/40 uppercase tracking-widest">Hotline / Zalo hỗ trợ</p>
                       <p className="text-base font-black text-yellow-400">{AUTHOR_INFO.phone}</p>
                    </div>
                 </div>

                 <div className="bg-white/5 p-4 rounded-2xl border border-white/5 flex items-center space-x-4 hover:bg-white/10 transition-colors cursor-pointer">
                    <div className="w-10 h-10 bg-emerald-600/20 text-emerald-400 rounded-xl flex items-center justify-center">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    </div>
                    <div>
                       <p className="text-[8px] font-black text-white/40 uppercase tracking-widest">Email Công vụ</p>
                       <p className="text-base font-black text-white">{AUTHOR_INFO.email}</p>
                    </div>
                 </div>
              </div>
           </div>
           
           <div className="mt-10 pt-6 border-t border-white/10 flex items-center justify-between">
              <div className="flex flex-col">
                 <p className="text-[10px] font-black uppercase text-blue-400 tracking-widest">Digital ID</p>
                 <p className="text-[9px] font-mono text-white/40">{AUTHOR_INFO.id}</p>
              </div>
              <div className="text-right">
                 <p className="text-[11px] font-black uppercase tracking-tighter">Bản quyền 2025</p>
                 <p className="text-[8px] text-white/30 uppercase tracking-[0.3em]">Hệ thống Quản trị Thông minh</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default LicenseManagement;
