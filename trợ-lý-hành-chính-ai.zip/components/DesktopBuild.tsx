
import React, { useState } from 'react';
import { User } from '../types';
import { AUTHOR_INFO } from '../constants';

interface DesktopBuildProps {
  user: User;
}

const DesktopBuild: React.FC<DesktopBuildProps> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<'PWA' | 'ELECTRON'>('PWA');
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const electronPackageJson = `{
  "name": "tro-ly-hanh-chinh-ai",
  "version": "1.0.0",
  "description": "Trợ lý ảo Hành chính thông minh",
  "main": "main.js",
  "scripts": {
    "start": "electron .",
    "pack": "electron-builder --dir",
    "dist": "electron-builder"
  },
  "build": {
    "appId": "com.pvk.gov.ai",
    "win": {
      "target": "nsis",
      "icon": "icon.ico"
    }
  },
  "devDependencies": {
    "electron": "^28.0.0",
    "electron-builder": "^24.9.1"
  }
}`;

  const electronMainJs = `const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1366,
    height: 900,
    title: "Trợ lý ảo Hành chính - Phạm Khoa",
    icon: path.join(__dirname, 'icon.ico'),
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  // Thay thế URL bằng địa chỉ website thực tế khi deploy
  win.loadURL('https://tro-ly-hanh-chinh.vercel.app');
  
  win.on('page-title-updated', (e) => e.preventDefault());
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});`;

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn pb-20">
      <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-200 overflow-hidden">
        <div className="official-gradient p-12 text-white relative">
          <div className="absolute inset-0 trong-dong-pattern opacity-10 pointer-events-none"></div>
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <h2 className="text-4xl font-black uppercase tracking-tight leading-none">Trung tâm Đóng gói Desktop</h2>
              <p className="text-blue-200 text-sm font-bold mt-4 uppercase tracking-[0.2em] opacity-80">Xuất bản phần mềm Windows (.EXE) cho cơ quan nhà nước</p>
            </div>
            <div className="flex flex-col items-center md:items-end">
               <div className="px-4 py-2 bg-white/10 rounded-xl border border-white/20 backdrop-blur-md mb-2">
                 <span className="text-[10px] font-black text-blue-300 uppercase tracking-widest block">Trạng thái phát hành</span>
                 <span className="text-sm font-bold text-emerald-400 flex items-center">
                   <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2 animate-pulse"></span>
                   Sẵn sàng đóng gói
                 </span>
               </div>
            </div>
          </div>
        </div>

        <div className="p-10">
          <div className="flex space-x-4 mb-12 bg-slate-100 p-2 rounded-[2rem]">
            <button 
              onClick={() => setActiveTab('PWA')}
              className={`flex-1 py-5 text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all ${activeTab === 'PWA' ? 'bg-white text-[#003366] shadow-xl scale-[1.02]' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Cách 1: Cài đặt PWA (Tốc độ & Hiện đại)
            </button>
            <button 
              onClick={() => setActiveTab('ELECTRON')}
              className={`flex-1 py-5 text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all ${activeTab === 'ELECTRON' ? 'bg-white text-[#003366] shadow-xl scale-[1.02]' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Cách 2: Build file .EXE (Chuyên nghiệp)
            </button>
          </div>

          {activeTab === 'PWA' ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 animate-fadeIn">
              <div className="space-y-8">
                <div className="p-8 bg-blue-50 rounded-[2.5rem] border border-blue-100 shadow-inner">
                  <h4 className="text-xs font-black text-blue-900 uppercase tracking-widest mb-6 flex items-center">
                    <span className="w-2 h-4 bg-blue-600 rounded mr-3"></span>
                    Tại sao chọn PWA?
                  </h4>
                  <ul className="space-y-4 text-sm text-slate-700 font-medium">
                    <li className="flex items-start"><span className="text-blue-600 mr-3">⚡</span> <b>Không chiếm dụng tài nguyên:</b> Chỉ tốn vài KB để cài đặt thay vì hàng trăm MB.</li>
                    <li className="flex items-start"><span className="text-blue-600 mr-3">🚀</span> <b>Truy cập nhanh:</b> Xuất hiện icon trên Desktop và thanh Taskbar như phần mềm xịn.</li>
                    <li className="flex items-start"><span className="text-blue-600 mr-3">🔄</span> <b>Luôn mới nhất:</b> Tự động cập nhật tính năng AI mà không cần cài lại.</li>
                    <li className="flex items-start"><span className="text-blue-600 mr-3">🔐</span> <b>An toàn:</b> Chạy trong môi trường bảo mật của trình duyệt Chrome/Edge.</li>
                  </ul>
                </div>
              </div>
              
              <div className="space-y-10">
                <h4 className="text-sm font-black text-slate-800 uppercase tracking-tight">Quy trình cài đặt (3 bước)</h4>
                <div className="space-y-8">
                  <div className="flex space-x-6 group">
                    <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-black text-lg shadow-xl shrink-0 group-hover:scale-110 transition-transform">1</div>
                    <div>
                      <p className="text-xs font-black text-slate-400 uppercase mb-1">Bước 1</p>
                      <p className="text-sm font-bold text-slate-700 leading-relaxed">Mở ứng dụng bằng Microsoft Edge hoặc Google Chrome trên máy tính của đồng chí.</p>
                    </div>
                  </div>
                  <div className="flex space-x-6 group">
                    <div className="w-12 h-12 rounded-2xl bg-[#003366] text-white flex items-center justify-center font-black text-lg shadow-xl shrink-0 group-hover:scale-110 transition-transform">2</div>
                    <div>
                      <p className="text-xs font-black text-slate-400 uppercase mb-1">Bước 2</p>
                      <p className="text-sm font-bold text-slate-700 leading-relaxed">Tìm biểu tượng <span className="inline-flex p-1.5 bg-slate-100 rounded-lg mx-1"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg></span> ở cuối thanh địa chỉ trình duyệt.</p>
                    </div>
                  </div>
                  <div className="flex space-x-6 group">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg shadow-xl shrink-0 group-hover:scale-110 transition-transform">3</div>
                    <div>
                      <p className="text-xs font-black text-slate-400 uppercase mb-1">Bước 3</p>
                      <p className="text-sm font-bold text-slate-700 leading-relaxed">Nhấn <b>"Cài đặt"</b>. Ứng dụng sẽ ngay lập tức được "ghim" vào Windows của đồng chí.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-12 animate-fadeIn">
              <div className="bg-amber-50 p-8 rounded-[2.5rem] border border-amber-200">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-10 h-10 bg-amber-600 text-white rounded-xl flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  </div>
                  <h4 className="text-sm font-black text-amber-900 uppercase">Yêu cầu Kỹ thuật</h4>
                </div>
                <p className="text-xs text-amber-800 font-bold leading-relaxed">
                  Đồng chí cần có môi trường <b>Node.js</b> đã cài đặt trên máy tính. Quy trình này phù hợp cho bộ phận Công nghệ thông tin muốn đóng gói thành file cài đặt .EXE duy nhất.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                 <div className="space-y-4">
                    <div className="flex justify-between items-center">
                       <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Tệp tin: package.json</h5>
                       <button onClick={() => copyToClipboard(electronPackageJson, 'pkg')} className="text-[9px] font-bold text-blue-600 hover:underline">{copied === 'pkg' ? 'Đã chép!' : 'Sao chép'}</button>
                    </div>
                    <pre className="p-6 bg-slate-900 text-emerald-400 rounded-3xl text-[11px] font-mono overflow-x-auto shadow-2xl">
                       {electronPackageJson}
                    </pre>
                 </div>
                 <div className="space-y-4">
                    <div className="flex justify-between items-center">
                       <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Tệp tin: main.js</h5>
                       <button onClick={() => copyToClipboard(electronMainJs, 'main')} className="text-[9px] font-bold text-blue-600 hover:underline">{copied === 'main' ? 'Đã chép!' : 'Sao chép'}</button>
                    </div>
                    <pre className="p-6 bg-slate-900 text-blue-300 rounded-3xl text-[11px] font-mono overflow-x-auto shadow-2xl">
                       {electronMainJs}
                    </pre>
                 </div>
              </div>

              <div className="p-10 bg-slate-50 rounded-[3rem] border border-slate-200">
                 <h4 className="text-sm font-black text-slate-800 uppercase mb-8 text-center tracking-widest">Lệnh biên dịch file .EXE</h4>
                 <div className="space-y-6 max-w-2xl mx-auto">
                    <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-200 shadow-sm group">
                       <code className="text-xs font-bold text-blue-700">npm install</code>
                       <span className="text-[9px] font-black text-slate-400 uppercase">Cài đặt thư viện build</span>
                    </div>
                    <div className="flex items-center justify-center">
                       <div className="w-px h-6 bg-slate-200"></div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-200 shadow-sm group">
                       <code className="text-xs font-bold text-blue-700">npm run dist</code>
                       <span className="text-[9px] font-black text-slate-400 uppercase">Biên dịch ra file cài đặt (.exe)</span>
                    </div>
                 </div>
                 <p className="text-center text-[10px] text-slate-400 font-bold mt-10 uppercase tracking-widest">File kết quả nằm trong thư mục <span className="text-blue-600">/dist</span></p>
              </div>
            </div>
          )}
        </div>

        <div className="p-10 bg-slate-50 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
           <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-red-600 rounded-xl flex flex-col items-center justify-center text-white text-[8px] font-black border border-red-400 shadow-lg">
                 <span>PHẠM</span>
                 <span className="text-yellow-400">KHOA</span>
              </div>
              <div>
                 <p className="text-sm font-black text-[#003366] uppercase leading-none">{AUTHOR_INFO.name}</p>
                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Cố vấn Kỹ thuật Hệ thống</p>
              </div>
           </div>
           <div className="flex space-x-4">
              <button onClick={() => window.print()} className="px-6 py-3 bg-white border border-slate-200 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-50 transition-colors">In hướng dẫn</button>
              <a href={`mailto:${AUTHOR_INFO.email}`} className="px-6 py-3 bg-[#003366] text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-xl">Gửi yêu cầu hỗ trợ build</a>
           </div>
        </div>
      </div>
    </div>
  );
};

export default DesktopBuild;
