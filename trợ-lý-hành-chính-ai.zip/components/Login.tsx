
import React, { useState } from 'react';
import { User } from '../types';
import { AUTHOR_INFO } from '../constants';

interface LoginProps {
  onLogin: (user: User) => void;
}

const NationalEmblem = () => (
  <div className="relative w-full h-full flex items-center justify-center bg-red-600 rounded-full border-4 border-yellow-500 shadow-lg p-2">
    <div className="absolute inset-0 rounded-full border border-yellow-400/30 animate-pulse"></div>
    <svg viewBox="0 0 24 24" className="w-full h-full text-yellow-400" fill="currentColor">
      <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
    </svg>
  </div>
);

// Nâng cấp: Dấu ấn cá nhân tác giả Phạm Văn Khoa chuyên nghiệp hơn
const PersonalSeal = () => (
  <div className="flex flex-col items-center space-y-3 opacity-90 hover:opacity-100 transition-all duration-700 transform hover:scale-110">
    <div className="relative w-16 h-16 flex items-center justify-center group">
      {/* Con dấu triện cổ điển kết hợp công nghệ */}
      <div className="absolute inset-0 bg-red-700 border-2 border-red-400 rounded-[1rem] rotate-3 shadow-[0_10px_30px_rgba(185,28,28,0.4)] group-hover:rotate-0 transition-all duration-500"></div>
      <div className="absolute inset-1 border border-white/20 rounded-[0.8rem] pointer-events-none"></div>
      <div className="relative z-10 flex flex-col items-center justify-center text-white font-serif leading-none tracking-tighter">
        <span className="text-[12px] font-black drop-shadow-md">PHẠM</span>
        <div className="w-10 h-[1.5px] bg-yellow-400 my-1 shadow-[0_0_5px_rgba(250,204,21,0.5)]"></div>
        <span className="text-[12px] font-black drop-shadow-md">KHOA</span>
      </div>
    </div>
    <div className="text-center">
      <p className="text-white/30 text-[8px] font-black uppercase tracking-[0.4em] mb-1">Architected by</p>
      <div className="px-3 py-1 bg-white/5 rounded-lg border border-white/5 shadow-inner">
        <p className="text-yellow-500 font-black uppercase tracking-[0.2em] text-[11px] drop-shadow-lg">{AUTHOR_INFO.name.toUpperCase()}</p>
      </div>
    </div>
  </div>
);

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    setTimeout(() => {
      const users = JSON.parse(localStorage.getItem('registered_users') || '{}');

      if (isRegistering) {
        if (users[formData.email]) {
          setError("Tài khoản này đã tồn tại trên hệ thống.");
          setIsLoading(false);
          return;
        }

        const newUser: User = {
          name: formData.name,
          email: formData.email,
          registrationDate: new Date().toISOString(),
        };

        users[formData.email] = { ...newUser, password: formData.password };
        localStorage.setItem('registered_users', JSON.stringify(users));
        onLogin(newUser);
      } else {
        const user = users[formData.email];
        if (user && (user.password === formData.password || user.password === 'google_oauth_bypass')) {
          onLogin({
            name: user.name,
            email: user.email,
            registrationDate: user.registrationDate,
            picture: user.picture
          });
        } else {
          setError("Thông tin đăng nhập không chính xác hoặc tài khoản chưa được kích hoạt.");
        }
      }
      setIsLoading(false);
    }, 1000);
  };

  const handleGoogleRegister = () => {
    setIsGoogleLoading(true);
    setError(null);

    setTimeout(() => {
      const googleUser: User = {
        name: "Cán bộ Trải nghiệm",
        email: "trainghiem.vien@gmail.com",
        picture: "https://lh3.googleusercontent.com/a/default-user=s96-c",
        registrationDate: new Date().toISOString(),
      };
      
      const users = JSON.parse(localStorage.getItem('registered_users') || '{}');
      if (!users[googleUser.email]) {
        users[googleUser.email] = { ...googleUser, password: 'google_oauth_bypass' };
        localStorage.setItem('registered_users', JSON.stringify(users));
      }

      onLogin(googleUser);
      setIsGoogleLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#001529] flex items-center justify-center p-6 relative overflow-hidden">
      <div className="login-trong-dong"></div>
      <div className="absolute inset-0 bg-gradient-to-tr from-[#001529] via-transparent to-[#002b4d] opacity-90"></div>

      <div className="max-w-md w-full animate-fadeIn relative z-10">
        <div className="text-center mb-8">
          <div className="inline-block w-24 h-24 mb-6 transform hover:scale-105 transition-transform duration-500">
            <NationalEmblem />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight mb-1 uppercase">Cổng Dịch vụ công & Quản trị AI</h1>
          <p className="text-yellow-500/80 font-bold uppercase tracking-[0.3em] text-[10px]">Hệ thống Trợ lý ảo Hành chính Việt Nam</p>
        </div>

        <div className="bg-white rounded-[2rem] shadow-[0_40px_120px_rgba(0,0,0,0.6)] overflow-hidden border border-white/10 glass-panel">
          <div className="p-10">
            <div className="flex bg-slate-100 p-1.5 rounded-2xl mb-8">
              <button 
                onClick={() => { setIsRegistering(false); setError(null); }}
                className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${!isRegistering ? 'bg-white text-[#003366] shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
              >
                Đăng nhập
              </button>
              <button 
                onClick={() => { setIsRegistering(true); setError(null); }}
                className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${isRegistering ? 'bg-white text-[#003366] shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
              >
                Cấp tài khoản
              </button>
            </div>

            <form onSubmit={handleAuth} className="space-y-5">
              {isRegistering && (
                <div className="space-y-1">
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 ml-1">Họ tên cán bộ / Công chức</label>
                  <input
                    required
                    type="text"
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 outline-none text-sm font-bold transition-all"
                    placeholder="Nguyễn Văn A"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
              )}

              <div className="space-y-1">
                <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 ml-1">Tài khoản Email công vụ (.gov.vn)</label>
                <input
                  required
                  type="email"
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 outline-none text-sm font-bold transition-all"
                  placeholder="canbo@ubnd.gov.vn"
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 ml-1">Mật khẩu xác thực</label>
                <input
                  required
                  type="password"
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 outline-none text-sm font-bold transition-all"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={e => setFormData({...formData, password: e.target.value})}
                />
              </div>

              {error && (
                <div className="p-4 bg-red-50 border border-red-100 rounded-2xl animate-shake">
                   <p className="text-[10px] text-red-600 font-bold leading-relaxed text-center uppercase tracking-tight">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-5 rounded-2xl font-black text-white transition-all shadow-xl flex items-center justify-center space-x-3 uppercase text-[10px] tracking-[0.2em] official-gradient hover:brightness-110 active:scale-[0.98]"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <span>{isRegistering ? 'Xác nhận Đăng ký' : 'Xác thực Truy cập'}</span>
                )}
              </button>
            </form>
          </div>
          
          <div className="bg-slate-50/80 p-6 border-t border-slate-100">
            <div className="flex flex-col items-center space-y-2">
              <div className="flex items-center space-x-2 text-emerald-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                <p className="text-[9px] font-black uppercase tracking-tight">KẾT NỐI AN TOÀN - MÃ HÓA AES-256</p>
              </div>
              <p className="text-[8px] text-slate-400 font-bold uppercase tracking-widest">
                Cần hỗ trợ? Liên hệ: <span className="text-blue-600">{AUTHOR_INFO.email}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Footer Dấu ấn cá nhân tác giả */}
        <div className="mt-12 flex flex-col items-center animate-slideUp">
          <div className="mb-6 flex justify-center space-x-8 opacity-20">
            <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse"></div>
            <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse [animation-delay:-0.2s]"></div>
            <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse [animation-delay:-0.4s]"></div>
          </div>
          
          <PersonalSeal />
          
          <p className="mt-10 text-white/30 text-[7px] font-black uppercase tracking-[0.5em]">Hệ thống Chuyển đổi số Quốc gia 2025</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
