
import React, { useState, useEffect } from 'react';
import { ViewMode, User } from '../types';
import { ICONS, AUTHOR_INFO } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  user: User;
  onLogout: () => void;
  daysLeft?: number;
}

const Layout: React.FC<LayoutProps> = ({ children, currentView, onViewChange, user, onLogout, daysLeft }) => {
  const [isCollapsed, setIsCollapsed] = useState(() => {
    const saved = localStorage.getItem('sidebar_collapsed');
    return saved === 'true';
  });

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('sidebar_collapsed', String(isCollapsed));
  }, [isCollapsed]);

  const menuItems = [
    { id: ViewMode.DASHBOARD, label: 'Tổng quan Hệ thống', icon: ICONS.Dashboard },
    { id: ViewMode.LEGAL_ASSISTANT, label: 'Trợ lý Pháp lý AI', icon: ICONS.Assistant },
    { id: ViewMode.KNOWLEDGE_BASE, label: 'Kho Tri thức số', icon: ICONS.Knowledge },
    { id: ViewMode.DRAFTING, label: 'Soạn thảo Văn bản', icon: ICONS.Draft },
    { id: ViewMode.DESKTOP_BUILD, label: 'Đóng gói Desktop', icon: () => (
      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    )},
    { id: ViewMode.PROFILE, label: 'Hồ sơ Cá nhân', icon: ICONS.Profile },
    { id: ViewMode.LICENSE_MANAGEMENT, label: 'Quản lý Bản quyền', icon: ICONS.Security },
  ];

  const userInitial = user.name ? user.name.charAt(0).toUpperCase() : '?';

  const toggleSidebar = () => setIsCollapsed(!isCollapsed);

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden text-slate-900 font-sans">
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-[40] lg:hidden backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 left-0 z-[50] lg:relative official-gradient text-white flex flex-col shadow-2xl transition-all duration-300 ease-in-out ${
          isCollapsed ? 'w-20' : 'w-80'
        } ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        <div className="absolute inset-0 trong-dong-pattern pointer-events-none opacity-5"></div>
        
        <div className={`p-6 border-b border-white/10 relative overflow-hidden flex items-center ${isCollapsed ? 'justify-center' : 'justify-between'}`}>
          {!isCollapsed && (
            <div className="flex items-center space-x-4 relative z-10 animate-fadeIn">
              <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center shadow-lg border-2 border-yellow-500 p-1">
                <svg viewBox="0 0 24 24" className="w-full h-full text-yellow-400" fill="currentColor">
                  <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
                </svg>
              </div>
              <div>
                <h1 className="text-sm font-black tracking-tight leading-tight uppercase">UBND DIGITAL</h1>
                <p className="text-[8px] text-blue-300 font-bold uppercase tracking-widest opacity-80">Trợ lý ảo</p>
              </div>
            </div>
          )}
          
          {isCollapsed && (
            <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center shadow-lg border-2 border-yellow-500 p-1 animate-fadeIn">
               <svg viewBox="0 0 24 24" className="w-6 h-6 text-yellow-400" fill="currentColor">
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
              </svg>
            </div>
          )}

          <button 
            onClick={toggleSidebar}
            className="hidden lg:flex absolute -right-0 top-1/2 -translate-y-1/2 w-6 h-12 bg-white/10 hover:bg-white/20 items-center justify-center rounded-l-md transition-colors z-20"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 transition-transform duration-500 ${isCollapsed ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
        </div>
        
        <nav className="flex-1 py-6 px-3 overflow-y-auto scrollbar-hide relative z-10">
          <ul className="space-y-1.5">
            {menuItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => {
                    onViewChange(item.id);
                    if (window.innerWidth < 1024) setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center group relative ${
                    isCollapsed ? 'justify-center p-3' : 'space-x-4 px-4 py-3.5'
                  } rounded-xl transition-all text-sm font-semibold ${
                    currentView === item.id 
                      ? 'bg-white text-[#003366] shadow-lg' 
                      : 'text-blue-100/70 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <span className={`${currentView === item.id ? 'text-[#003366]' : 'text-blue-300 group-hover:text-white'} transition-colors shrink-0`}>
                    <item.icon />
                  </span>
                  {!isCollapsed && <span className="truncate animate-fadeIn">{item.label}</span>}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className={`mt-auto border-t border-white/10 bg-black/20 p-4 transition-all ${isCollapsed ? 'items-center flex flex-col' : ''}`}>
           {!isCollapsed ? (
             <div className="flex flex-col space-y-3 animate-fadeIn">
                <div className="flex items-center space-x-3 bg-white/10 p-3 rounded-2xl border border-white/10 shadow-inner group">
                   <div className="w-10 h-10 bg-red-600 rounded-xl flex flex-col items-center justify-center text-[8px] font-black shadow-lg border border-red-400 transform -rotate-3 group-hover:rotate-0 transition-transform">
                      <span className="text-white leading-none">PHẠM</span>
                      <span className="text-yellow-400 leading-none">KHOA</span>
                   </div>
                   <div className="flex-1">
                      <p className="text-[11px] font-black text-white uppercase tracking-tighter">{AUTHOR_INFO.name}</p>
                      <p className="text-[8px] text-blue-300 font-bold uppercase opacity-60">System Architect</p>
                   </div>
                </div>
             </div>
           ) : (
             <div className="w-10 h-10 bg-red-600 rounded-xl flex flex-col items-center justify-center text-[7px] font-black shadow-lg border border-red-400 animate-fadeIn group cursor-help relative">
                <span className="text-white leading-none">PV</span>
                <span className="text-yellow-400 leading-none">KHOA</span>
             </div>
           )}
        </div>

        <div className="p-4 border-t border-white/10 bg-black/10">
          <button 
            onClick={() => onViewChange(ViewMode.PROFILE)}
            className={`w-full flex items-center group transition-all ${isCollapsed ? 'justify-center' : 'space-x-3 p-2 rounded-xl hover:bg-white/5'}`}
          >
            <div className="w-8 h-8 rounded-full bg-blue-500 border-2 border-white/20 flex items-center justify-center text-white font-bold text-[10px] shadow-inner">
              {userInitial}
            </div>
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 lg:px-10 flex items-center justify-between shadow-sm z-10">
          <div className="flex items-center space-x-4">
             <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
             </button>
             <h2 className="text-sm sm:text-lg font-black text-slate-800 tracking-tight uppercase truncate">
               {menuItems.find(m => m.id === currentView)?.label}
             </h2>
          </div>
        </header>
        <div className="flex-1 overflow-hidden p-4 sm:p-6 lg:p-10 relative bg-[#F1F5F9]">
          <div className="relative h-full z-0 overflow-y-auto scrollbar-hide">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Layout;
