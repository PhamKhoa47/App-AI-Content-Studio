
import React, { useState, useEffect } from 'react';
import { User, UserActivity } from '../types';
import { getActivities, logActivity } from '../services/activityService';

interface ProfileProps {
  user: User;
  daysLeft: number;
  onUpdate: (updatedUser: User) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, daysLeft, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name || '',
    email: user.email || '',
    unit: user.unit || '',
    department: user.department || '',
    position: user.position || '',
  });
  const [activities, setActivities] = useState<UserActivity[]>([]);

  useEffect(() => {
    setActivities(getActivities(user.email));
    setFormData({
      name: user.name || '',
      email: user.email || '',
      unit: user.unit || '',
      department: user.department || '',
      position: user.position || '',
    });
  }, [user]);

  const handleSave = () => {
    const updatedUser: User = {
      ...user,
      name: formData.name,
      unit: formData.unit,
      department: formData.department,
      position: formData.position,
    };
    onUpdate(updatedUser);
    setIsEditing(false);
    logActivity(user.email, 'LOGIN', 'Cập nhật thông tin hồ sơ cán bộ');
  };

  const userInitial = user.name ? user.name.charAt(0).toUpperCase() : '?';

  const getActivityIcon = (type: UserActivity['type']) => {
    switch (type) {
      case 'LOGIN': return <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>;
      case 'LEGAL_SEARCH': return <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>;
      case 'DOC_DRAFT': return <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>;
      case 'DOC_SAVE': return <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" /></svg>;
      default: return <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
    }
  };

  const getActivityColor = (type: UserActivity['type']) => {
    switch (type) {
      case 'LOGIN': return 'bg-emerald-100 text-emerald-600';
      case 'LEGAL_SEARCH': return 'bg-blue-100 text-blue-600';
      case 'DOC_DRAFT': return 'bg-indigo-100 text-indigo-600';
      case 'DOC_SAVE': return 'bg-amber-100 text-amber-600';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fadeIn">
      {/* Profile Header Card */}
      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200 overflow-hidden">
        <div className="h-32 official-gradient relative">
          <div className="absolute top-0 left-0 w-full h-full guilloche-pattern opacity-10"></div>
          <div className="absolute -bottom-12 left-10 flex items-end space-x-6">
            <div className="w-32 h-32 rounded-3xl bg-white p-2 shadow-2xl">
              {user.picture ? (
                <img src={user.picture} alt="Avatar" className="w-full h-full rounded-2xl object-cover" />
              ) : (
                <div className="w-full h-full rounded-2xl bg-slate-100 flex items-center justify-center text-blue-600 text-4xl font-black border border-slate-200 uppercase shadow-inner">
                  {userInitial}
                </div>
              )}
            </div>
            <div className="pb-4">
              <h2 className="text-3xl font-black text-white drop-shadow-sm uppercase">{user.name}</h2>
              <p className="text-blue-100 font-bold text-xs uppercase tracking-widest opacity-80">{user.email}</p>
            </div>
          </div>
        </div>
        
        <div className="pt-16 pb-8 px-10 flex justify-end items-center space-x-4">
           <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${daysLeft > 0 ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-red-50 text-red-700 border-red-100'}`}>
              {daysLeft > 0 ? 'Tài khoản Đang hoạt động' : 'Đã hết hạn bản quyền'}
           </span>
           <button 
            onClick={() => isEditing ? handleSave() : setIsEditing(true)}
            className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all shadow-lg ${isEditing ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-slate-900 text-white hover:bg-black'}`}
           >
             {isEditing ? 'Lưu thay đổi' : 'Cấu hình hồ sơ'}
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-200">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-8 flex items-center border-b pb-4 border-slate-100">
               Thông tin chi tiết cán bộ
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Họ và tên</label>
                <input 
                  type="text" 
                  disabled={!isEditing}
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-100 outline-none transition-all disabled:opacity-70"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Email hệ thống</label>
                <input 
                  type="email" 
                  disabled
                  value={formData.email}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold opacity-50 cursor-not-allowed"
                />
              </div>

              {/* Mục Đơn vị - Mới */}
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Cơ quan / Đơn vị</label>
                <input 
                  type="text" 
                  disabled={!isEditing}
                  placeholder="VD: UBND Thành phố, Sở Nội vụ..."
                  value={formData.unit}
                  onChange={(e) => setFormData({...formData, unit: e.target.value})}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-100 outline-none transition-all disabled:opacity-70"
                />
              </div>

              {/* Mục Phòng ban - Mới */}
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Phòng / Ban / Bộ phận</label>
                <input 
                  type="text" 
                  disabled={!isEditing}
                  placeholder="VD: Phòng Hành chính - Tổng hợp..."
                  value={formData.department}
                  onChange={(e) => setFormData({...formData, department: e.target.value})}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-100 outline-none transition-all disabled:opacity-70"
                />
              </div>

              {/* Mục Chức vụ - Mới */}
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Chức vụ cán bộ</label>
                <input 
                  type="text" 
                  disabled={!isEditing}
                  placeholder="VD: Trưởng phòng, Chuyên viên..."
                  value={formData.position}
                  onChange={(e) => setFormData({...formData, position: e.target.value})}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-100 outline-none transition-all disabled:opacity-70"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Ngày tham gia</label>
                <div className="w-full px-5 py-4 bg-slate-100 border border-slate-200 rounded-2xl text-sm font-bold text-slate-600 shadow-inner uppercase tracking-wider">
                  {new Date(user.registrationDate).toLocaleDateString('vi-VN', { day: '2-digit', month: 'long', year: 'numeric' })}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-200">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-8 flex items-center border-b pb-4 border-slate-100">
               Nhật ký hoạt động chuyên sâu
            </h3>
            <div className="space-y-8 relative">
              <div className="absolute left-4 top-2 bottom-2 w-0.5 bg-slate-100"></div>
              {activities.length === 0 ? (
                <p className="text-center py-10 text-slate-400 text-xs font-bold uppercase">Chưa ghi nhận hoạt động nào</p>
              ) : (
                activities.map((act) => (
                  <div key={act.id} className="relative pl-12 group">
                    <div className={`absolute left-0 w-8 h-8 rounded-xl flex items-center justify-center z-10 shadow-lg group-hover:scale-110 transition-transform ${getActivityColor(act.type)}`}>
                       {getActivityIcon(act.type)}
                    </div>
                    <div className="flex flex-col">
                       <div className="flex justify-between items-center mb-1">
                          <p className="text-xs font-black text-slate-800 uppercase tracking-wider">{act.type.replace('_', ' ')}</p>
                          <span className="text-[9px] font-bold text-slate-400 uppercase">{new Date(act.timestamp).toLocaleString('vi-VN')}</span>
                       </div>
                       <p className="text-sm text-slate-600 font-medium">{act.description}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
           <div className="official-gradient p-10 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-full h-full guilloche-pattern opacity-10"></div>
              <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:rotate-12 transition-transform">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <h4 className="text-[10px] font-black text-blue-200 uppercase tracking-[0.2em] mb-6 relative z-10">Thời lượng dùng thử</h4>
              <div className="space-y-6 relative z-10">
                 <div className="flex justify-between items-end">
                    <p className="text-6xl font-black">{daysLeft}</p>
                    <p className="text-[10px] font-black text-blue-300 pb-2 uppercase tracking-widest">Ngày còn lại</p>
                 </div>
                 <div className="w-full bg-black/20 h-3 rounded-full overflow-hidden shadow-inner">
                    <div className="bg-white h-full rounded-full transition-all duration-1000" style={{ width: `${(daysLeft/7)*100}%` }}></div>
                 </div>
                 <p className="text-[10px] text-blue-100 font-bold leading-relaxed opacity-80 uppercase tracking-tight">
                   Hết hạn ngày <b>{new Date(new Date(user.registrationDate).getTime() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('vi-VN')}</b>.
                 </p>
                 <button className="w-full py-4 bg-white text-[#003366] rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-50 transition-colors shadow-2xl">
                   Nâng cấp Bản quyền
                 </button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
