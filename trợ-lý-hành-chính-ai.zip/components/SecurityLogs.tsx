
// This file has been removed and replaced by LicenseManagement.tsx
export default {};
