
import React from 'react';
import { User } from '../types';

interface TrialExpiredProps {
  user: User;
  onLogout: () => void;
}

const TrialExpired: React.FC<TrialExpiredProps> = ({ user, onLogout }) => {
  const userInitial = user.name ? user.name.charAt(0).toUpperCase() : '?';

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="max-w-xl w-full">
        <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-200 overflow-hidden">
          <div className="bg-red-600 p-10 text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-32 w-32" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="w-20 h-20 bg-white/20 rounded-3xl mx-auto flex items-center justify-center mb-6 backdrop-blur-md">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m0 0v2m0-2h2m-2 0H10m4-11a4 4 0 11-8 0 4 4 0 018 0zm-4 7v3m0 0v3m0-3h3m-3 0H7" />
              </svg>
            </div>
            <h2 className="text-2xl font-black text-white uppercase tracking-wider">Hết hạn dùng thử</h2>
            <p className="text-red-100 text-sm mt-2 font-medium">Phiên bản trải nghiệm 07 ngày đã kết thúc</p>
          </div>

          <div className="p-10 space-y-8">
            <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
              {user.picture ? (
                <img src={user.picture} alt="User" className="w-12 h-12 rounded-full border-2 border-white shadow-sm" />
              ) : (
                <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold border-2 border-white shadow-sm">
                  {userInitial}
                </div>
              )}
              <div>
                <p className="text-sm font-bold text-slate-800">{user.name}</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{user.email}</p>
              </div>
              <div className="ml-auto text-right">
                <p className="text-[10px] font-black text-red-500 uppercase tracking-tighter">Trạng thái</p>
                <p className="text-xs font-bold text-slate-600">Ngừng kích hoạt</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-widest border-b pb-2">Hướng dẫn đăng ký</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Để tiếp tục sử dụng toàn bộ tính năng của <b>Trợ lý ảo Hành chính</b>, quý khách vui lòng thực hiện thủ tục đăng ký bản quyền chính thức.
              </p>
              
              <div className="grid grid-cols-1 gap-4">
                <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-2xl border border-blue-100 group hover:bg-blue-600 transition-all cursor-pointer">
                  <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center group-hover:bg-white group-hover:text-blue-600 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-blue-600 uppercase tracking-widest group-hover:text-blue-100">Liên hệ quản trị viên</p>
                    <p className="text-sm font-bold text-slate-800 group-hover:text-white">Phạm Văn Khoa: 0989113602</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6 flex items-center justify-between border-t border-slate-100">
              <button onClick={onLogout} className="text-xs font-bold text-slate-400 hover:text-slate-800 transition-colors uppercase tracking-widest">
                Đăng xuất tài khoản
              </button>
              <p className="text-[10px] font-bold text-slate-300 uppercase">Hệ thống chuyển đổi số Quốc gia</p>
            </div>
          </div>
        </div>
        
        <p className="mt-8 text-center text-[11px] text-slate-400 font-medium italic">
          * Dữ liệu cá nhân vẫn được bảo toàn và sẽ khả dụng ngay sau khi kích hoạt lại tài khoản chính thức.
        </p>
      </div>
    </div>
  );
};

export default TrialExpired;
