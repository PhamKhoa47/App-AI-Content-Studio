
import React, { useState, useEffect, useRef } from 'react';
import { getDocPreview, chatWithDoc } from '../services/geminiService';
import { User, KnowledgeDocument, Message } from '../types';
import { getKnowledgeIndex, updateKnowledgeIndex, logActivity } from '../services/activityService';

interface KnowledgeBaseProps {
  user: User;
}

const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({ user }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Tất cả');
  const [activeSource, setActiveSource] = useState<string>('Tất cả');
  const [selectedDoc, setSelectedDoc] = useState<KnowledgeDocument | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isDriveConnected, setIsDriveConnected] = useState(false);
  const [isNotebookConnected, setIsNotebookConnected] = useState(false);
  const [allDocuments, setAllDocuments] = useState<KnowledgeDocument[]>([]);
  
  // Chat inside preview
  const [docChatInput, setDocChatInput] = useState('');
  const [isChatting, setIsChatting] = useState(false);

  const folderInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Load database từ localStorage khi khởi tạo
  useEffect(() => {
    const savedDocs = getKnowledgeIndex(user.email);
    const initialDocs: KnowledgeDocument[] = [
      { id: 'sys1', title: 'Luật Ban hành văn bản quy phạm pháp luật 2015', type: 'Luật', category: 'Pháp quy', source: 'Hệ thống', date: '22/06/2015', size: '2.5 MB', status: 'Còn hiệu lực', department: 'Quốc hội' },
      { id: 'sys2', title: 'Nghị định 30/2020/NĐ-CP về công tác văn thư', type: 'Nghị định', category: 'Hành chính', source: 'Hệ thống', date: '05/03/2020', size: '1.2 MB', status: 'Còn hiệu lực', department: 'Chính phủ' },
    ];
    
    // Hợp nhất dữ liệu hệ thống và dữ liệu cá nhân đã lưu
    const merged = [...initialDocs];
    savedDocs.forEach(sd => {
      if (!merged.find(m => m.id === sd.id)) merged.push(sd);
    });
    setAllDocuments(merged);
  }, [user.email]);

  // Đồng bộ database mỗi khi allDocuments thay đổi
  useEffect(() => {
    const personalDocs = allDocuments.filter(d => d.source !== 'Hệ thống');
    updateKnowledgeIndex(user.email, personalDocs);
  }, [allDocuments, user.email]);

  const filteredDocs = allDocuments.filter(d => 
    (activeCategory === 'Tất cả' || d.category === activeCategory) &&
    (activeSource === 'Tất cả' || d.source === activeSource) &&
    d.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFolderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsSyncing(true);
    const newDocs: KnowledgeDocument[] = Array.from(files)
      .filter(file => file.name.match(/\.(pdf|doc|docx|txt)$/i))
      .map(file => ({
        id: `local_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        title: file.name,
        type: file.name.split('.').pop()?.toUpperCase() || 'FILE',
        category: 'Hành chính',
        source: 'Cục bộ',
        date: new Date(file.lastModified).toLocaleDateString('vi-VN'),
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
        status: 'Còn hiệu lực',
        department: 'Máy tính cá nhân',
        chatHistory: []
      }));

    setAllDocuments(prev => [...prev, ...newDocs]);
    logActivity(user.email, 'KNOWLEDGE_UPLOAD', `Đã đồng bộ ${newDocs.length} tệp từ máy tính`);
    setIsSyncing(false);
  };

  const handlePreview = async (doc: KnowledgeDocument) => {
    setSelectedDoc(doc);
    
    // Nếu tài liệu đã có tóm tắt, không cần gọi AI nữa
    if (doc.summary) return;

    setIsGenerating(true);
    try {
      const summary = await getDocPreview(doc.title);
      const updatedDoc = { ...doc, summary: summary || 'Không thể trích xuất nội dung.' };
      setAllDocuments(prev => prev.map(d => d.id === doc.id ? updatedDoc : d));
      setSelectedDoc(updatedDoc);
    } catch (error) {
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDocChat = async () => {
    if (!docChatInput.trim() || isChatting || !selectedDoc) return;
    const userMsgText = docChatInput;
    setDocChatInput('');
    
    const userMsg: Message = { role: 'user', text: userMsgText, timestamp: new Date().toISOString() };
    const currentHistory = selectedDoc.chatHistory || [];
    const newHistoryWithUser = [...currentHistory, userMsg];
    
    // Update UI nhanh
    setSelectedDoc({ ...selectedDoc, chatHistory: newHistoryWithUser });
    setIsChatting(true);

    try {
      const aiResponse = await chatWithDoc(selectedDoc.title, selectedDoc.summary || '', userMsgText);
      const aiMsg: Message = { role: 'model', text: aiResponse || '...', timestamp: new Date().toISOString() };
      const finalHistory = [...newHistoryWithUser, aiMsg];
      
      const updatedDoc = { ...selectedDoc, chatHistory: finalHistory };
      setAllDocuments(prev => prev.map(d => d.id === selectedDoc.id ? updatedDoc : d));
      setSelectedDoc(updatedDoc);
    } catch (error) {
      console.error(error);
    } finally {
      setIsChatting(false);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-6 animate-fadeIn">
      <input type="file" ref={folderInputRef} className="hidden" {...({ webkitdirectory: "", directory: "" } as any)} onChange={handleFolderChange} />

      {/* Integration Hub Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div onClick={() => folderInputRef.current?.click()} className="p-5 rounded-2xl bg-white border border-slate-200 shadow-md hover:border-blue-400 transition-all cursor-pointer flex items-center space-x-4">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 2v10m0 0l-4-4m4 4l4-4M5 18h14" /></svg>
          </div>
          <div>
            <h4 className="text-sm font-bold">Thư mục Cục bộ</h4>
            <p className="text-[10px] text-slate-400 font-bold uppercase">Nhấn để đồng bộ file</p>
          </div>
        </div>
        {/* Placeholder for Drive/Notebook... */}
      </div>

      {/* Filter & Table */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Hiển thị:</span>
            {['Tất cả', 'Pháp quy', 'Hành chính'].map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${activeCategory === cat ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>{cat}</button>
            ))}
          </div>
          <div className="relative">
            <input type="text" className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none w-64" placeholder="Tìm kiếm tài liệu..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
      </div>

      <div className="flex-1 overflow-y-auto bg-white rounded-2xl shadow-sm border border-slate-200">
        <table className="min-w-full divide-y divide-slate-100 text-xs">
          <thead className="bg-slate-50/50">
            <tr>
              <th className="px-6 py-4 text-left font-bold text-slate-400 uppercase tracking-widest">Tên văn bản</th>
              <th className="px-6 py-4 text-left font-bold text-slate-400 uppercase tracking-widest">Nguồn</th>
              <th className="px-6 py-4 text-left font-bold text-slate-400 uppercase tracking-widest">Đơn vị</th>
              <th className="px-6 py-4 text-right font-bold text-slate-400 uppercase tracking-widest">Trạng thái</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filteredDocs.map(doc => (
              <tr key={doc.id} onClick={() => handlePreview(doc)} className="hover:bg-blue-50/30 transition-colors cursor-pointer group">
                <td className="px-6 py-4 flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                  </div>
                  <span className="font-semibold text-slate-700">{doc.title}</span>
                </td>
                <td className="px-6 py-4"><span className="px-2 py-0.5 rounded-full font-bold uppercase text-[9px] bg-slate-100 text-slate-500">{doc.source}</span></td>
                <td className="px-6 py-4 text-slate-500">{doc.department}</td>
                <td className="px-6 py-4 text-right">
                  {doc.summary ? <span className="text-emerald-600 font-black uppercase text-[8px] tracking-widest flex items-center justify-end"><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-1"></div>Đã phân tích</span> : <span className="text-slate-300 font-bold uppercase text-[8px]">Chưa xem</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Preview & Chat Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-fadeIn">
          <div className="bg-white w-full max-w-6xl h-[90vh] rounded-[2.5rem] shadow-2xl flex overflow-hidden">
            <div className="flex-1 flex flex-col border-r border-slate-100">
              <div className="p-8 border-b border-slate-50 flex justify-between items-center">
                <h3 className="text-xl font-bold text-slate-800 line-clamp-1">{selectedDoc.title}</h3>
                <button onClick={() => setSelectedDoc(null)} className="text-slate-400 p-2 hover:bg-slate-100 rounded-full"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
              </div>
              <div className="flex-1 overflow-y-auto p-10 font-serif leading-relaxed text-slate-700">
                {isGenerating ? (
                  <div className="h-full flex flex-col items-center justify-center">
                    <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">AI đang đọc văn bản...</p>
                  </div>
                ) : (
                  <div className="max-w-2xl mx-auto space-y-6">
                    <div className="flex items-center space-x-2 border-b pb-2">
                       <div className="w-2 h-4 bg-blue-600 rounded"></div>
                       <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Tóm tắt tri thức tập trung</span>
                    </div>
                    <p className="text-base whitespace-pre-wrap">{selectedDoc.summary}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="w-[400px] bg-slate-50 flex flex-col">
              <div className="p-6 border-b border-slate-200 bg-white">
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest">Hỏi đáp về văn bản</h4>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {(selectedDoc.chatHistory || []).map((chat, i) => (
                  <div key={i} className={`flex ${chat.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-4 rounded-2xl text-xs leading-relaxed ${chat.role === 'user' ? 'bg-[#003366] text-white' : 'bg-white text-slate-700 border border-slate-200'}`}>
                      {chat.text}
                    </div>
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>
              <div className="p-6 bg-white border-t border-slate-200">
                <div className="relative">
                  <input type="text" value={docChatInput} onChange={(e) => setDocChatInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleDocChat()} placeholder="Đặt câu hỏi về văn bản..." className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none" />
                  <button onClick={handleDocChat} disabled={!docChatInput.trim() || isChatting} className="absolute right-2 top-2 p-1.5 text-blue-600 disabled:text-slate-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBase;
