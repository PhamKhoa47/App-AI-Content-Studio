
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { chatWithLegalAIStream } from '../services/geminiService';
import { Message, User, ChatSession } from '../types';
import { logActivity, saveChatSession, getChatSessions } from '../services/activityService';
import { AUTHOR_INFO } from '../constants';

interface LegalAssistantProps {
  user: User;
}

interface ExtendedMessage extends Message {
  sources?: { title?: string; uri?: string }[];
}

// Audio Decoding & Encoding Utilities (Standardized)
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const LegalAssistant: React.FC<LegalAssistantProps> = ({ user }) => {
  const [currentSessionId, setCurrentSessionId] = useState<string>(`session_${Date.now()}`);
  const [messages, setMessages] = useState<ExtendedMessage[]>([]);
  const [pastSessions, setPastSessions] = useState<ChatSession[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Voice & Live States
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [voiceTranscription, setVoiceTranscription] = useState('');
  const [aiVoiceResponse, setAiVoiceResponse] = useState('');
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const sessionRef = useRef<any>(null);
  const audioContexts = useRef<{input: AudioContext | null, output: AudioContext | null}>({input: null, output: null});
  const nextStartTime = useRef(0);
  const audioSources = useRef<Set<AudioBufferSourceNode>>(new Set());
  const transcriptionRef = useRef({ input: '', output: '' });

  useEffect(() => {
    const sessions = getChatSessions(user.email, 'LEGAL');
    setPastSessions(sessions);
    if (sessions.length > 0) {
      loadSession(sessions[0]);
    } else {
      setMessages([{ 
        role: 'model', 
        text: 'Kính chào đồng chí! Tôi là Trợ lý Pháp vụ ảo cấp cao. Đồng chí cần tra cứu quy định pháp luật hay quy trình hành chính cụ thể nào?', 
        timestamp: new Date().toISOString() 
      }]);
    }
    return () => stopVoiceMode();
  }, [user.email]);

  useEffect(() => {
    if (messages.length > 0) {
      const session: ChatSession = {
        id: currentSessionId,
        title: messages.find(m => m.role === 'user')?.text.substring(0, 50) || 'Truy vấn pháp lý mới',
        messages: messages,
        lastUpdate: new Date().toISOString(),
        type: 'LEGAL'
      };
      saveChatSession(user.email, session);
    }
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages]);

  const loadSession = (session: ChatSession) => {
    setCurrentSessionId(session.id);
    setMessages(session.messages);
  };

  const startNewSession = () => {
    stopVoiceMode();
    setCurrentSessionId(`session_${Date.now()}`);
    setMessages([{ 
      role: 'model', 
      text: 'Hệ thống đã sẵn sàng cho phiên tra cứu mới. Mời đồng chí nhập nội dung yêu cầu.', 
      timestamp: new Date().toISOString() 
    }]);
    setPastSessions(getChatSessions(user.email, 'LEGAL'));
  };

  const startVoiceMode = async () => {
    try {
      setIsVoiceMode(true);
      transcriptionRef.current = { input: '', output: '' };
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      audioContexts.current.input = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 16000});
      audioContexts.current.output = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = audioContexts.current.input!.createMediaStreamSource(stream);
            const scriptProcessor = audioContexts.current.input!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContexts.current.input!.destination);
            (window as any).voiceStream = stream;
            (window as any).voiceProcessor = scriptProcessor;
          },
          onmessage: async (m: LiveServerMessage) => {
            if (m.serverContent?.inputTranscription) {
              const text = m.serverContent.inputTranscription.text;
              transcriptionRef.current.input += text;
              setVoiceTranscription(transcriptionRef.current.input);
            }
            if (m.serverContent?.outputTranscription) {
              const text = m.serverContent.outputTranscription.text;
              transcriptionRef.current.output += text;
              setAiVoiceResponse(transcriptionRef.current.output);
            }

            const base64Audio = m.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && audioContexts.current.output) {
              const ctx = audioContexts.current.output;
              nextStartTime.current = Math.max(nextStartTime.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const sourceNode = ctx.createBufferSource();
              sourceNode.buffer = buffer;
              sourceNode.connect(ctx.destination);
              sourceNode.onended = () => audioSources.current.delete(sourceNode);
              sourceNode.start(nextStartTime.current);
              nextStartTime.current += buffer.duration;
              audioSources.current.add(sourceNode);
            }

            if (m.serverContent?.turnComplete) {
              setMessages(prev => [
                ...prev,
                { role: 'user', text: transcriptionRef.current.input || "Truy vấn bằng giọng nói", timestamp: new Date().toISOString() },
                { role: 'model', text: transcriptionRef.current.output, timestamp: new Date().toISOString() }
              ]);
              transcriptionRef.current = { input: '', output: '' };
              setVoiceTranscription('');
              setAiVoiceResponse('');
            }
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: 'Bạn là Trợ lý Pháp vụ Quốc gia cho cán bộ UBND Việt Nam. Trả lời trang trọng, chính xác, ngắn gọn, trích dẫn văn bản pháp luật.'
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      stopVoiceMode();
    }
  };

  const stopVoiceMode = () => {
    setIsVoiceMode(false);
    if (sessionRef.current) sessionRef.current.close();
    if ((window as any).voiceStream) (window as any).voiceStream.getTracks().forEach((t: any) => t.stop());
    if ((window as any).voiceProcessor) (window as any).voiceProcessor.disconnect();
    audioSources.current.forEach(s => s.stop());
    audioSources.current.clear();
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const currentInput = input;
    setInput('');
    setIsLoading(true);

    const userMsg: ExtendedMessage = { role: 'user', text: currentInput, timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);

    const aiMsg: ExtendedMessage = { role: 'model', text: '', timestamp: new Date().toISOString(), sources: [] };
    setMessages(prev => [...prev, aiMsg]);

    try {
      const stream = await chatWithLegalAIStream(currentInput);
      let fullText = '';
      let collectedSources: { title?: string; uri?: string }[] = [];
      
      for await (const chunk of stream) {
        fullText += chunk.text;
        const chunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (chunks) {
          chunks.forEach((c: any) => {
            if (c.web?.uri && !collectedSources.find(s => s.uri === c.web.uri)) {
              collectedSources.push({ title: c.web.title, uri: c.web.uri });
            }
          });
        }
        setMessages(prev => {
          const newMsgs = [...prev];
          const last = newMsgs[newMsgs.length - 1];
          last.text = fullText;
          last.sources = collectedSources;
          return newMsgs;
        });
      }
      logActivity(user.email, 'LEGAL_SEARCH', `Tra cứu: ${currentInput.substring(0, 40)}...`);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-full gap-8 animate-fadeIn p-2 relative overflow-hidden">
      {/* Sidebar: History */}
      <div className="w-[380px] flex flex-col space-y-6 h-full overflow-hidden">
        <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl flex flex-col flex-1 overflow-hidden">
          <div className="p-8 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center">
            <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Phiên Tra cứu AI
            </h4>
            <button onClick={startNewSession} className="p-2 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
            {pastSessions.map((s) => (
              <button 
                key={s.id} 
                onClick={() => loadSession(s)}
                className={`w-full text-left p-6 rounded-[2rem] border transition-all transform active:scale-[0.98] ${
                  currentSessionId === s.id 
                  ? 'bg-blue-50 border-blue-200 shadow-lg' 
                  : 'bg-white border-slate-100 hover:bg-slate-50'
                }`}
              >
                <p className={`text-[13px] font-bold leading-relaxed line-clamp-2 mb-3 ${currentSessionId === s.id ? 'text-blue-900' : 'text-slate-700'}`}>
                  {s.title}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{new Date(s.lastUpdate).toLocaleDateString('vi-VN')}</span>
                  {currentSessionId === s.id && <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>}
                </div>
              </button>
            ))}
          </div>

          <div className="p-8 border-t border-slate-50 bg-slate-900 relative">
             <div className="absolute inset-0 trong-dong-pattern opacity-10 pointer-events-none"></div>
             <div className="flex items-center space-x-4 relative z-10">
                <div className="w-12 h-12 bg-red-600 rounded-xl flex flex-col items-center justify-center text-white text-[7px] font-black shadow-2xl border border-red-400 transform -rotate-3 transition-transform">
                   <span>PHẠM</span>
                   <span className="text-yellow-400">KHOA</span>
                </div>
                <div className="flex-1">
                   <p className="text-[11px] font-black text-white uppercase leading-none tracking-tight">{AUTHOR_INFO.name}</p>
                   <p className="text-[8px] text-blue-400 font-bold uppercase tracking-[0.2em] mt-2">GOV-AI AUTHENTICATED</p>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Main Chat Interface */}
      <div className="flex-1 flex flex-col bg-white rounded-[2.5rem] shadow-2xl border border-slate-200 overflow-hidden relative">
        <header className="px-10 py-6 border-b border-slate-50 flex justify-between items-center bg-white/80 backdrop-blur-md z-20">
          <div className="flex items-center space-x-5">
            <div className="w-12 h-12 official-gradient rounded-2xl flex items-center justify-center text-white shadow-xl rotate-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16" /></svg>
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 uppercase tracking-tight">Trung tâm Phân tích Pháp lý AI</h3>
              <div className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">Live Database 2025</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
             <button 
                onClick={isVoiceMode ? stopVoiceMode : startVoiceMode} 
                className={`flex items-center space-x-3 px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${isVoiceMode ? 'bg-red-600 text-white animate-pulse shadow-red-200' : 'bg-slate-900 text-white hover:bg-black shadow-lg'}`}
             >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4" /></svg>
                <span>{isVoiceMode ? 'Live Mode' : 'Đàm thoại AI'}</span>
             </button>
          </div>
        </header>

        {/* Conversation Area */}
        <div className="flex-1 overflow-y-auto p-12 space-y-12 scrollbar-hide bg-[#FBFCFE]" ref={scrollRef}>
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-slideUp`}>
              <div className={`max-w-[85%] flex flex-col space-y-3 ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                {m.role === 'model' && (
                  <div className="flex items-center space-x-2 px-4 mb-1">
                    <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Trợ lý Pháp vụ Trả lời</span>
                  </div>
                )}
                <div className={`p-8 rounded-[2.5rem] shadow-sm architectural-line-height ${
                  m.role === 'user' 
                  ? 'bg-[#003366] text-white rounded-tr-none shadow-blue-900/10' 
                  : 'bg-white border border-slate-100 text-slate-800 rounded-tl-none font-medium shadow-slate-200/50'
                }`} style={m.role === 'model' ? { fontFamily: '"Times New Roman", Times, serif', fontSize: '16px' } : {}}>
                  <div className="whitespace-pre-wrap">{m.text}</div>
                  
                  {m.sources && m.sources.length > 0 && (
                    <div className="mt-8 pt-6 border-t border-slate-50 space-y-4">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Căn cứ pháp lý trích dẫn:</p>
                      <div className="flex flex-wrap gap-3">
                        {m.sources.map((s, idx) => (
                          <a key={idx} href={s.uri} target="_blank" rel="noopener noreferrer" 
                            className="flex items-center space-x-3 px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-[11px] font-bold text-blue-700 hover:bg-blue-100 hover:border-blue-200 transition-all shadow-sm group">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4" /></svg>
                            <span className="truncate max-w-[280px]">{s.title || 'Văn bản gốc'}</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-[0.2em] px-4">
                  {new Date(m.timestamp).toLocaleTimeString('vi-VN')}
                </span>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start px-4">
               <div className="bg-white border border-slate-100 p-6 rounded-[2.5rem] flex items-center space-x-4 shadow-xl shadow-slate-200/20 animate-pulse">
                  <div className="flex space-x-1.5">
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  </div>
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Đang trích xuất Điều - Khoản văn bản...</span>
               </div>
            </div>
          )}
        </div>

        {/* Improved Voice HUD (Bottom Right) */}
        {isVoiceMode && (
          <div className="absolute bottom-32 right-12 w-[420px] bg-slate-900/95 backdrop-blur-2xl rounded-[3rem] p-10 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.6)] border border-white/10 z-40 animate-slideUp">
             <div className="flex items-center justify-between mb-10">
                <div className="flex items-center space-x-5">
                   <div className="relative">
                      <div className="w-5 h-5 bg-red-500 rounded-full animate-ping opacity-25"></div>
                      <div className="absolute inset-0 w-5 h-5 bg-red-500 rounded-full animate-pulse shadow-red-500/50"></div>
                   </div>
                   <span className="text-sm font-black text-white uppercase tracking-[0.2em]">Voice Portal Active</span>
                </div>
                <button onClick={stopVoiceMode} className="p-3 text-white/40 hover:text-white bg-white/5 hover:bg-white/10 rounded-full transition-all">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6" /></svg>
                </button>
             </div>
             <div className="space-y-8">
                {/* Visualizer */}
                <div className="flex items-center justify-center space-x-1.5 h-12">
                   {[...Array(24)].map((_, i) => (
                     <div key={i} className="flex-1 bg-blue-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.3)]" style={{ height: `${20 + Math.random() * 80}%`, animationDelay: `${i * 0.05}s` }}></div>
                   ))}
                </div>
                <div className="bg-white/5 rounded-3xl p-8 border border-white/5 shadow-inner">
                   <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-4 flex items-center">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" /></svg>
                     Đang nhận diện giọng nói:
                   </p>
                   <p className="text-base text-white/90 font-medium italic leading-relaxed line-clamp-3">
                      {voiceTranscription || 'Đang sẵn sàng lắng nghe đồng chí...'}
                   </p>
                </div>
                {aiVoiceResponse && (
                  <div className="bg-emerald-500/10 rounded-3xl p-8 border border-emerald-500/10 animate-fadeIn">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-4">AI Phản hồi:</p>
                    <p className="text-base text-emerald-50/90 font-medium leading-relaxed line-clamp-3">
                      {aiVoiceResponse}
                    </p>
                  </div>
                )}
             </div>
          </div>
        )}

        {/* Input Bar */}
        <div className="p-10 bg-white border-t border-slate-50 relative">
          <div className="max-w-5xl mx-auto flex items-end space-x-5">
            <div className="flex-1 relative group">
              <textarea 
                rows={1} 
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())} 
                placeholder="Tra cứu thủ tục hành chính, quy định chuyên ngành, căn cứ pháp lý..." 
                className="w-full pl-8 pr-16 py-6 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] focus:ring-8 focus:ring-blue-100/50 outline-none transition-all text-sm font-semibold resize-none shadow-inner placeholder:text-slate-400" 
              />
              <button 
                onClick={handleSend} 
                disabled={!input.trim() || isLoading} 
                className={`absolute right-3 bottom-3 p-5 rounded-[2rem] text-white shadow-2xl transition-all transform active:scale-95 ${!input.trim() || isLoading ? 'bg-slate-300' : 'official-gradient hover:brightness-110 shadow-blue-900/30'}`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
              </button>
            </div>
          </div>
          <div className="flex justify-center space-x-8 mt-6">
             <div className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Grounding with Google Search</p>
             </div>
             <div className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Gov Knowledge Sync</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegalAssistant;
