
import React, { useMemo } from 'react';
import { User } from '../types';
import { getActivities, getKnowledgeIndex, getDocVersions, getChatSessions } from '../services/activityService';
import { AUTHOR_INFO } from '../constants';

interface DashboardProps {
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const activities = useMemo(() => getActivities(user.email), [user.email]);
  const knowledgeCount = useMemo(() => getKnowledgeIndex(user.email).length, [user.email]);
  const draftCount = useMemo(() => getDocVersions(user.email).length, [user.email]);
  const chatCount = useMemo(() => getChatSessions(user.email, 'LEGAL').length, [user.email]);

  const stats = [
    { label: 'Kho tri thức số', value: 2 + knowledgeCount, sub: 'Tài liệu đã index', color: 'blue', icon: '📚' },
    { label: 'Trợ lý Pháp lý', value: chatCount, sub: 'Phiên tra cứu AI', color: 'indigo', icon: '⚖️' },
    { label: 'Dự thảo Văn bản', value: draftCount, sub: 'Bản thảo lưu trữ', color: 'emerald', icon: '✍️' },
    { label: 'Hiệu suất AI', value: '1.2s', sub: 'Độ trễ phản hồi', color: 'amber', icon: '⚡' },
  ];

  return (
    <div className="space-y-10 animate-fadeIn max-w-7xl mx-auto pb-20 relative">
      {/* Background Decor */}
      <div className="absolute -top-20 -right-20 w-96 h-96 bg-blue-400/5 rounded-full blur-3xl pointer-events-none"></div>

      {/* 1. Chỉ số Vận hành (Stats) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
        {stats.map((s, idx) => (
          <div key={idx} className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-200 hover:shadow-xl hover:-translate-y-1 transition-all group overflow-hidden relative">
            <div className="absolute -right-2 -bottom-2 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity transform group-hover:scale-125 duration-700">
               <span className="text-8xl font-black">{s.icon}</span>
            </div>
            <div className="flex justify-between items-start mb-4 relative z-10">
               <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shadow-inner ${
                 s.color === 'blue' ? 'bg-blue-50 text-blue-600' : 
                 s.color === 'indigo' ? 'bg-indigo-50 text-indigo-600' :
                 s.color === 'emerald' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
               }`}>
                 {s.icon}
               </div>
               <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest group-hover:text-slate-500">Hệ thống {AUTHOR_INFO.name.split(' ').pop()}</span>
            </div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.15em] mb-1 relative z-10">{s.label}</p>
            <div className="flex items-baseline space-x-2 relative z-10">
              <p className={`text-3xl font-black text-slate-800`}>{s.value}</p>
              <p className="text-[10px] font-bold text-slate-400">{s.sub}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-10 relative z-10">
        {/* 2. Sơ đồ Tổng thể Hệ thống (Visual System Map) */}
        <div className="xl:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none group-hover:opacity-10 transition-opacity">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-64 h-64" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 002-2h-2a2 2 0 00-2 2" /></svg>
             </div>
             
             <div className="flex justify-between items-start mb-10 border-b pb-4 border-slate-100">
                <h3 className="text-xs font-black text-[#003366] uppercase tracking-[0.2em] flex items-center">
                  <span className="w-2 h-4 bg-red-600 rounded mr-3"></span>
                  Sơ đồ Cấu trúc Hệ thống Trợ lý ảo
                </h3>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest border border-slate-200 px-3 py-1 rounded-full">Architected by {AUTHOR_INFO.name}</span>
             </div>

             <div className="space-y-4 relative z-10">
                {/* Layer 1: Users */}
                <div className="flex justify-center">
                  <div className="px-8 py-3 bg-[#003366] text-white rounded-xl shadow-lg text-[10px] font-black uppercase tracking-widest border border-white/20">
                    NGƯỜI DÙNG (Cán bộ | Lãnh đạo)
                  </div>
                </div>
                <div className="h-6 flex justify-center"><div className="w-px bg-slate-200"></div></div>

                {/* Layer 2: UI */}
                <div className="flex justify-center">
                  <div className="px-10 py-4 bg-white border-2 border-blue-100 text-[#003366] rounded-2xl shadow-md text-[10px] font-black uppercase tracking-widest flex items-center space-x-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    <span>Giao diện Người dùng (Phát triển bởi Phạm Khoa)</span>
                  </div>
                </div>
                <div className="h-6 flex justify-center"><div className="w-px bg-slate-200"></div></div>

                {/* Layer 4: AI Layer (The Core) */}
                <div className="p-6 bg-gradient-to-br from-blue-600 to-indigo-800 rounded-3xl shadow-2xl relative group-hover:scale-[1.01] transition-transform duration-500">
                  <div className="absolute inset-0 trong-dong-pattern opacity-10"></div>
                  <div className="relative z-10 flex flex-col items-center text-white">
                    <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center mb-3">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </div>
                    <p className="text-[11px] font-black uppercase tracking-[0.2em] mb-2">AI RAG ENGINE (Hạt nhân trí tuệ)</p>
                    <div className="flex space-x-4 text-[8px] font-bold opacity-70 uppercase">
                       <span>Phân tích NLP</span>
                       <span>•</span>
                       <span>Truy xuất RAG</span>
                       <span>•</span>
                       <span>Trích dẫn Điều khoản</span>
                    </div>
                  </div>
                </div>
                <div className="h-6 flex justify-center"><div className="w-px bg-slate-200"></div></div>

                {/* Layer 5: Data */}
                <div className="flex justify-center">
                  <div className="px-10 py-5 bg-emerald-50 border-2 border-emerald-100 text-emerald-800 rounded-2xl shadow-sm text-[10px] font-black uppercase tracking-widest flex items-center space-x-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" /></svg>
                    <span>Cơ sở dữ liệu lưu trữ (Authenticated)</span>
                  </div>
                </div>
             </div>
          </div>

          {/* Footer Signature on Dashboard */}
          <div className="flex items-center justify-center space-x-4 py-10">
             <div className="h-px bg-slate-200 flex-1"></div>
             <div className="flex flex-col items-center">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-2">Hệ thống vận hành bởi trí tuệ nhân tạo</p>
                <div className="flex items-center space-x-3">
                   <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center text-white text-[8px] font-black shadow-lg">PVK</div>
                   <p className="text-sm font-black text-[#003366] uppercase tracking-tighter">Bản quyền của {AUTHOR_INFO.name}</p>
                </div>
             </div>
             <div className="h-px bg-slate-200 flex-1"></div>
          </div>
        </div>

        {/* 3. Hoạt động & Nhật ký & Support Card */}
        <div className="space-y-6">
          {/* Support Card (New) */}
          <div className="bg-[#001529] p-8 rounded-[2rem] text-white shadow-2xl relative overflow-hidden group">
            <div className="absolute inset-0 trong-dong-pattern opacity-5 pointer-events-none"></div>
            <div className="relative z-10">
               <div className="flex items-center space-x-4 mb-6">
                  <div className="w-12 h-12 bg-red-600 rounded-xl flex flex-col items-center justify-center text-[8px] font-black border border-red-400 shadow-lg group-hover:scale-110 transition-transform">
                     <span>PHẠM</span>
                     <span className="text-yellow-400">KHOA</span>
                  </div>
                  <div>
                     <h4 className="text-sm font-black uppercase tracking-tight">Kỹ thuật & Bản quyền</h4>
                     <p className="text-[9px] text-blue-400 font-bold uppercase tracking-widest">{AUTHOR_INFO.role}</p>
                  </div>
               </div>
               <div className="space-y-4">
                  <a href={`mailto:${AUTHOR_INFO.email}`} className="flex items-center space-x-3 p-3 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                     <svg className="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path></svg>
                     <span className="text-xs font-bold truncate">{AUTHOR_INFO.email}</span>
                  </a>
                  <a href={`tel:${AUTHOR_INFO.phone}`} className="flex items-center space-x-3 p-3 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                     <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 005.455 5.455l.774-1.548a1 1 0 011.06-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"></path></svg>
                     <span className="text-xs font-bold">{AUTHOR_INFO.phone}</span>
                  </a>
               </div>
            </div>
          </div>

          {/* Nhật ký công vụ */}
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 flex flex-col relative overflow-hidden">
             <div className="absolute inset-0 trong-dong-pattern opacity-[0.02] pointer-events-none"></div>
            <div className="flex justify-between items-center mb-8 border-b pb-4 border-slate-100 relative z-10">
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">Nhật ký Hệ thống</h3>
              <span className="text-[9px] font-black text-blue-500 bg-blue-50 px-2 py-1 rounded-lg uppercase">Live Log</span>
            </div>
            
            <div className="space-y-6 overflow-y-auto pr-2 scrollbar-hide max-h-[400px] relative z-10">
              {activities.length === 0 ? (
                <div className="text-center py-10">
                   <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Chưa ghi nhận hoạt động</p>
                </div>
              ) : (
                activities.slice(0, 8).map((log, i) => (
                  <div key={log.id} className="relative pl-8 group">
                    <div className={`absolute left-1 top-2 w-2.5 h-2.5 rounded-full border-2 border-white shadow-sm z-10 ${
                      log.type === 'LOGIN' ? 'bg-emerald-500' : 'bg-blue-500'
                    }`}></div>
                    <div className="flex flex-col">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-slate-800 uppercase tracking-tight">{log.type}</span>
                        <span className="text-[8px] font-bold text-slate-400">{new Date(log.timestamp).toLocaleTimeString('vi-VN')}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">{log.description}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
