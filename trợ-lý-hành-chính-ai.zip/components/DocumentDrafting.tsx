
import React, { useState, useRef, useEffect } from 'react';
import { generateDraft, refineDraftContent, suggestPhrasing, standardizeStyle } from '../services/geminiService';
import { User, DocVersion } from '../types';
import { saveDocVersion, getDocVersions, logActivity, deleteDocVersion } from '../services/activityService';

interface DocumentDraftingProps {
  user: User;
}

const DocumentDrafting: React.FC<DocumentDraftingProps> = ({ user }) => {
  const [formData, setFormData] = useState({
    type: 'QUYẾT ĐỊNH',
    subject: '',
    reason: '',
    content: '',
    signer: user.name || '',
    position: user.position || 'CHÁNH VĂN PHÒNG',
    agency: user.unit || 'UBND TỈNH ...',
    location: 'Hà Nội',
    docNumber: '.../QĐ-UBND',
  });
  const [draft, setDraft] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [refineInput, setRefineInput] = useState('');
  const [isRefining, setIsRefining] = useState(false);
  const [activeStep, setActiveStep] = useState<1 | 2 | 3>(1); 
  const [savedVersions, setSavedVersions] = useState<DocVersion[]>([]);
  const [showSaveToast, setShowSaveToast] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [zoom, setZoom] = useState(100);
  
  const [phrasingInput, setPhrasingInput] = useState('');
  const [phrasingSuggestions, setPhrasingSuggestions] = useState<string>('');
  const [isSuggesting, setIsSuggesting] = useState(false);
  
  const previewRef = useRef<HTMLDivElement>(null);

  useEffect(() => { setSavedVersions(getDocVersions(user.email)); }, [user.email]);

  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      signer: prev.signer || user.name || '',
      position: (prev.position || user.position || 'CHÁNH VĂN PHÒNG').toUpperCase(),
      agency: (prev.agency || user.unit || 'UBND TỈNH ...').toUpperCase()
    }));
  }, [user]);

  const handleGenerate = async () => {
    if (!formData.subject || !formData.content) return;
    setIsGenerating(true);
    try {
      const result = await generateDraft(formData.type, formData);
      setDraft(result || '');
      logActivity(user.email, 'DOC_DRAFT', `Khởi tạo: ${formData.subject}`);
      setActiveStep(2);
    } catch (error) { console.error(error); } finally { setIsGenerating(false); }
  };

  const handleQuickAction = async (action: 'standardize' | 'expand' | 'shorten') => {
    if (!draft || isRefining) return;
    setIsRefining(true);
    try {
      let result = '';
      if (action === 'standardize') result = await standardizeStyle(draft);
      else if (action === 'expand') result = await refineDraftContent(draft, "Phát triển các ý chi tiết, đầy đủ và chuyên nghiệp hơn.");
      else if (action === 'shorten') result = await refineDraftContent(draft, "Tóm gọn văn bản, súc tích.");
      if (result) setDraft(result);
    } catch (error) { console.error(error); } finally { setIsRefining(false); }
  };

  const handleGetPhrasing = async () => {
    if (!phrasingInput.trim() || isSuggesting) return;
    setIsSuggesting(true);
    try { const result = await suggestPhrasing(phrasingInput); setPhrasingSuggestions(result); } catch (error) { console.error(error); } finally { setIsSuggesting(false); }
  };

  const handleRefine = async () => {
    if (!refineInput.trim() || !draft || isRefining) return;
    setIsRefining(true);
    const instruction = refineInput; setRefineInput('');
    try { const result = await refineDraftContent(draft, instruction); setDraft(result || draft); } catch (error) { console.error(error); } finally { setIsRefining(false); }
  };

  const handleSave = () => { if (!draft) return; saveDocVersion(user.email, `Bản lưu: ${formData.subject || 'Không tiêu đề'}`, draft, formData.type); setSavedVersions(getDocVersions(user.email)); setShowSaveToast(true); setTimeout(() => setShowSaveToast(false), 3000); };

  const handleRestore = (version: DocVersion) => { setDraft(version.content); setFormData(prev => ({ ...prev, type: version.type })); setActiveStep(2); };

  const handleDelete = (id: string) => { deleteDocVersion(user.email, id); setSavedVersions(getDocVersions(user.email)); };

  const handleExportWord = () => {
    if (!previewRef.current) return;
    const htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><meta charset='utf-8'><style>
          @page WordSection1 { size: 21.0cm 29.7cm; margin: 2.0cm 1.5cm 2.0cm 3.0cm; }
          body { font-family: 'Times New Roman', serif; font-size: 14.0pt; line-height: 1.5; color: black; }
          p { margin: 0; padding: 0; text-align: justify; }
          .bold { font-weight: bold; } .center { text-align: center; } .uppercase { text-transform: uppercase; }
        </style></head>
      <body><div>
          <table style="width:100%; margin-bottom: 20pt;"><tr><td style="width: 45%; text-align: center;"><p class="bold uppercase">${formData.agency}</p><p>Số: ${formData.docNumber}</p><p>───────</p></td><td style="width: 55%; text-align: center;"><p class="bold uppercase">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p><p class="bold">Độc lập - Tự do - Hạnh phúc</p><p>──────────────</p></td></tr></table>
          <p style="text-align: right; font-style: italic; margin-bottom: 20pt;">${formData.location}, ngày ${new Date().getDate()} tháng ${new Date().getMonth() + 1} năm ${new Date().getFullYear()}</p>
          <p class="bold center uppercase" style="font-size: 15pt;">${formData.type}</p><p class="bold center italic" style="margin-bottom: 30pt;">${formData.subject}</p>
          <div style="margin-bottom: 40pt;">${draft.split('\n').map(line => `<p style="margin-bottom: 10pt; text-indent: 1.27cm;">${line}</p>`).join('')}</div>
          <table style="width:100%;"><tr><td style="width: 45%; font-size: 12pt;"><p class="bold italic">Nơi nhận:</p><p>- Như trên;</p><p>- Lưu: VT, ${user.department || 'HC'}.</p></td><td style="width: 55%; text-align: center;"><p class="bold uppercase">${formData.position}</p><p style="margin-top: 70pt;" class="bold">${formData.signer}</p></td></tr></table>
      </div></body></html>
    `;
    const blob = new Blob(['\ufeff', htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a'); link.href = url; link.download = `${formData.subject.replace(/\s+/g, '_')}.doc`; document.body.appendChild(link); link.click(); document.body.removeChild(link);
  };

  const types = [{ name: 'QUYẾT ĐỊNH', icon: '⚖️' }, { name: 'TỜ TRÌNH', icon: '📝' }, { name: 'CÔNG VĂN', icon: '✉️' }, { name: 'GIẤY MỜI', icon: '📅' }, { name: 'THÔNG BÁO', icon: '📢' }];

  return (
    <div className={`flex h-full gap-8 animate-fadeIn relative p-2 ${isFullscreen ? 'fixed inset-0 z-[100] bg-slate-950 p-0 gap-0' : ''}`}>
      {showSaveToast && <div className="fixed top-24 right-10 z-[110] bg-emerald-600 text-white px-6 py-4 rounded-2xl shadow-2xl animate-slideDown flex items-center space-x-3"><span className="text-xs font-black uppercase tracking-widest">Lưu thành công</span></div>}
      
      <div className={`w-[450px] flex flex-col space-y-6 transition-all duration-300 ${isFullscreen ? 'w-0 opacity-0 overflow-hidden' : ''}`}>
        <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-200 overflow-hidden flex flex-col flex-1 glass-panel">
          <div className="flex border-b border-slate-100 bg-slate-50/30">
            <button onClick={() => setActiveStep(1)} className={`flex-1 py-5 text-[9px] font-black uppercase tracking-[0.2em] transition-all ${activeStep === 1 ? 'text-[#003366] border-b-2 border-[#003366] bg-white' : 'text-slate-400'}`}>1. Thiết lập</button>
            <button onClick={() => draft && setActiveStep(2)} disabled={!draft} className={`flex-1 py-5 text-[9px] font-black uppercase tracking-[0.2em] transition-all ${activeStep === 2 ? 'text-[#003366] border-b-2 border-[#003366] bg-white' : 'text-slate-400'} disabled:opacity-30`}>2. AI Hỗ trợ</button>
            <button onClick={() => setActiveStep(3)} className={`flex-1 py-5 text-[9px] font-black uppercase tracking-[0.2em] transition-all ${activeStep === 3 ? 'text-[#003366] border-b-2 border-[#003366] bg-white' : 'text-slate-400'}`}>Lịch sử</button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {activeStep === 1 && (
              <div className="space-y-6 animate-fadeIn">
                <div className="grid grid-cols-2 gap-2">{types.map(t => (<button key={t.name} onClick={() => setFormData({...formData, type: t.name})} className={`p-3 text-left rounded-xl border transition-all flex items-center space-x-2 ${formData.type === t.name ? 'bg-[#003366] text-white border-[#003366]' : 'bg-slate-50 text-slate-600 border-slate-100'}`}><span className="text-lg">{t.icon}</span><span className="text-[9px] font-bold uppercase">{t.name}</span></button>))}</div>
                <div className="space-y-4">
                  <div className="space-y-1"><label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Cơ quan ban hành</label><input className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none text-xs font-bold uppercase" value={formData.agency} onChange={e => setFormData({...formData, agency: e.target.value.toUpperCase()})} /></div>
                  <div className="space-y-1"><label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Trích yếu văn bản</label><textarea rows={2} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none text-xs font-semibold" value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} /></div>
                  <div className="space-y-1"><label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Nội dung / Ý chính</label><textarea rows={3} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none text-xs font-medium" value={formData.content} onChange={e => setFormData({...formData, content: e.target.value})} /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1"><label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Người ký</label><input className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none text-xs font-bold" value={formData.signer} onChange={e => setFormData({...formData, signer: e.target.value})} /></div>
                    <div className="space-y-1"><label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Chức vụ</label><input className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none text-xs font-bold uppercase" value={formData.position} onChange={e => setFormData({...formData, position: e.target.value.toUpperCase()})} /></div>
                  </div>
                </div>
                <button onClick={handleGenerate} disabled={isGenerating || !formData.subject} className={`w-full py-4 rounded-xl font-black text-white transition-all shadow-lg uppercase text-[9px] tracking-widest ${isGenerating ? 'bg-slate-300' : 'official-gradient'}`}>Khởi tạo văn bản</button>
              </div>
            )}
            {activeStep === 2 && (
              <div className="flex flex-col h-full space-y-6 animate-fadeIn">
                <div className="grid grid-cols-3 gap-2">
                   <button onClick={() => handleQuickAction('standardize')} disabled={isRefining} className="flex flex-col items-center p-3 bg-blue-50 border border-blue-100 rounded-xl"><span className="text-xl mb-1">🏛️</span><span className="text-[8px] font-black text-blue-700 uppercase">Chuẩn Nghị định 30</span></button>
                   <button onClick={() => handleQuickAction('expand')} disabled={isRefining} className="flex flex-col items-center p-3 bg-emerald-50 border border-emerald-100 rounded-xl"><span className="text-xl mb-1">📈</span><span className="text-[8px] font-black text-emerald-700 uppercase">Phát triển ý</span></button>
                   <button onClick={() => handleQuickAction('shorten')} disabled={isRefining} className="flex flex-col items-center p-3 bg-amber-50 border border-amber-100 rounded-xl"><span className="text-xl mb-1">✂️</span><span className="text-[8px] font-black text-amber-700 uppercase">Tóm gọn súc tích</span></button>
                </div>
                <div className="space-y-3">
                   <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Gợi ý câu chữ AI</label>
                   <div className="relative"><input type="text" value={phrasingInput} onChange={e => setPhrasingInput(e.target.value)} placeholder="Nhập đoạn cần sửa..." className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none" /><button onClick={handleGetPhrasing} disabled={isSuggesting} className="absolute right-2 top-2 p-1.5 text-blue-600">{isSuggesting ? '...' : '→'}</button></div>
                   {phrasingSuggestions && <div className="bg-white p-3 rounded-xl border border-blue-100 text-[10px] text-slate-600 italic whitespace-pre-wrap">{phrasingSuggestions}</div>}
                </div>
                <div className="space-y-3">
                   <textarea rows={4} value={refineInput} onChange={e => setRefineInput(e.target.value)} placeholder="Yêu cầu sửa đổi khác..." className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none text-xs" />
                   <button onClick={handleRefine} disabled={isRefining || !refineInput.trim()} className="w-full py-4 official-gradient text-white rounded-xl text-[9px] font-black uppercase shadow-lg">Áp dụng hiệu chỉnh AI</button>
                </div>
                <div className="grid grid-cols-2 gap-2"><button onClick={handleSave} className="py-3 border-2 border-slate-100 text-[#003366] rounded-xl text-[9px] font-black uppercase">Lưu dự thảo</button><button onClick={handleExportWord} className="py-3 bg-blue-100 text-blue-700 rounded-xl text-[9px] font-black uppercase">Xuất file .doc</button></div>
              </div>
            )}
            {activeStep === 3 && (
              <div className="space-y-3 animate-fadeIn">{savedVersions.map(v => (<div key={v.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex justify-between items-center"><p className="text-[10px] font-extrabold text-slate-800 line-clamp-1">{v.name}</p><div className="flex space-x-1"><button onClick={() => handleRestore(v)} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-[8px] font-black uppercase">Mở</button><button onClick={() => handleDelete(v.id)} className="p-1.5 text-red-400 hover:bg-red-50 rounded-lg">X</button></div></div>))}</div>
            )}
          </div>
        </div>
      </div>

      <div className={`flex-1 flex flex-col overflow-hidden relative transition-all duration-500 ${isFullscreen ? 'h-screen w-screen rounded-none' : 'bg-slate-200/40 rounded-[2.5rem] border border-slate-300/50 shadow-inner'}`}>
        <div className={`flex justify-between items-center py-3 px-6 relative z-30 print:hidden border-b ${isFullscreen ? 'bg-slate-900 border-slate-800' : 'bg-white/70 backdrop-blur-xl border-slate-200'}`}>
          <div className="flex items-center space-x-4"><div className="w-2 h-2 rounded-full bg-emerald-500 shadow-sm"></div><div className="flex flex-col"><span className={`text-[8px] font-black uppercase tracking-[0.1em] ${isFullscreen ? 'text-slate-400' : 'text-slate-500'}`}>Preview</span><span className={`text-[10px] font-extrabold ${isFullscreen ? 'text-blue-100' : 'text-slate-800'}`}>A4 Paper - Standard 14pt</span></div></div>
          <div className="flex items-center space-x-2">
            <div className={`flex items-center px-2 py-1 bg-white border border-slate-200 rounded-xl`}><button onClick={() => setZoom(Math.max(30, zoom - 10))} className="p-1">-</button><span className="text-[9px] font-black w-8 text-center">{zoom}%</span><button onClick={() => setZoom(Math.min(200, zoom + 10))} className="p-1">+</button></div>
            <button onClick={() => setIsFullscreen(!isFullscreen)} className="p-2 bg-white border rounded-xl shadow-sm">{isFullscreen ? 'Exit' : 'Full'}</button>
            <button onClick={handleExportWord} className="px-4 py-2 bg-[#003366] text-white rounded-xl font-black text-[9px] uppercase shadow-lg">Xuất Word</button>
          </div>
        </div>

        <div className={`flex-1 overflow-auto flex justify-center scrollbar-hide ${isFullscreen ? 'bg-slate-950 pt-12' : 'bg-slate-400/5 py-10 shadow-inner'}`}>
          <div className="relative h-fit" style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top center' }}>
            <div ref={previewRef} id="printable-a4" className="w-[210mm] min-h-[297mm] bg-white a4-shadow relative p-[20mm_15mm_20mm_30mm]" style={{ fontFamily: '"Times New Roman", Times, serif', boxSizing: 'border-box', color: 'black', lineHeight: '1.5' }}>
              <div className="flex justify-between items-start mb-6">
                <div className="w-[45%] text-center"><p className="font-bold uppercase text-[13pt]">{formData.agency}</p><p className="text-[12pt]">Số: {formData.docNumber}</p><p>───────</p></div>
                {/* Fixed 'class' to 'className' in the following paragraph tags to resolve TypeScript error on line 186 */}
                <div className="w-[55%] text-center"><p className="bold uppercase text-[13pt]">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p><p className="bold text-[14pt]">Độc lập - Tự do - Hạnh phúc</p><p>──────────────</p></div>
              </div>
              <div className="text-right italic text-[14pt] mb-8">{formData.location}, ngày {new Date().getDate()} tháng {new Date().getMonth()+1} năm {new Date().getFullYear()}</div>
              <div className="text-center font-bold uppercase text-[15pt] mb-2">{formData.type}</div>
              <div className="text-center font-bold italic text-[14pt] mb-10 leading-relaxed max-w-[80%] mx-auto">{formData.subject}</div>
              <div className="text-[14pt] text-justify space-y-4">
                {draft ? (
                  <div className="whitespace-pre-wrap outline-none" contentEditable suppressContentEditableWarning onInput={(e) => setDraft((e.target as HTMLDivElement).innerText)}>
                    {draft}
                  </div>
                ) : (
                  <div className="h-[120mm] flex flex-col items-center justify-center opacity-[0.03] select-none"><p className="text-5xl font-black uppercase tracking-[0.5em]">HÀNH CHÍNH</p></div>
                )}
              </div>
              <div className="flex mt-20 w-full items-start">
                <div className="w-[45%] text-left">
                  {/* Hệ thống quản lý phần Nơi nhận riêng biệt để cán bộ không bị trùng lặp */}
                  <div className="font-bold italic text-[12pt] mb-2 underline">Nơi nhận:</div>
                  <div className="text-[11pt] leading-relaxed">- Như trên;<br />- Lưu: VT, {user.department || 'HC'}.</div>
                </div>
                <div className="w-[55%] text-center">
                    <div className="font-bold uppercase text-[13pt]">{formData.position}</div>
                    <div className="text-[12pt] italic mt-1">(Ký, ghi rõ họ tên và đóng dấu)</div>
                    <div className="font-bold mt-28 text-[14pt] uppercase tracking-tight">{formData.signer}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentDrafting;
